/* XPM */
static char *TVonscreen[] = {
/* width height num_colors chars_per_pixel */
"   104    27       3            1",
/* colors */
". c #ff0000",
"l c #ffffff",
"m c none",
/* pixels */
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm.mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm..mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm..mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm..mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmm.....................mmmmmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
".........................mmmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmm.............mmmmm....mmmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmm....mmmmmmmm.....mmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmm...mmmmmmmmm.....mmmmm..llllllllmmmmmmmmmmmmmmllllllmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmm.....mmmmmmmmm.....mmmmm.ll.mmmmllmmmmmmmmmmmmmllmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmm.....mmmmmmmmm.....mmmmmll..mmmmmllmmllmmllmmmmllmmmmmmmmmllllmmmlmlllmmmlllmmmmmmllmmmmmllmmllmm",
"mmmmmmm....mmmmmmmmmm......mm..ll..mmmmmllmmlllllllmmmmllmmmmmmmllllllmllllllmllllllmmmllllllmmmlllllllm",
"mmmmmmm....mmmmmmmmmmm.....mm..ll.mmmmmmllmmlllmmmlmmmmllllmmmmllmmmmmmlllmmmmllmmmllmmlmmmmllmmlllmmllm",
"mmmmmmm....mmmmmmmmmmm.....mm..ll.mmmmmmllmmlllmmmllmmmmmllllmmllmmmmmmllmmmmmlllllllmllllllllmmlllmmllm",
"mmmmmm.....mmmmmmmmmmm.....m...ll.mmmmmmllmmlllmmmllmmmmmmlllmmllmmmmmmllmmmmmlllllllmllllllllmmlllmmllm",
"mmmmmm....mmmmmmmmmmmm..........llmmmmmmllmmlllmmmllmmmmmmmllmmllmmmmmmllmmmmmllmmmmmmmlmmmmmmmmlllmmllm",
"mmmmmm....mmmmmmmmmmmmmm.........llmmmmllmmmlllmmmllmmlmmmlllmmlllmmmmmllmmmmmllmmmmmmmllmmmmmmmlllmmllm",
"mmmmmm....mmmmmmmmmmmmmm.........lllllllmmmmlllmmmllmmlllllllmmmllllllmllmmmmmmllllllmmmllllllmmlllmmllm",
"mmmmmm....mmmmmmmmmmmmmm.........mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmm...mmmmmmmmmmmmmmmm.......mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmm...mmmmmmmmmmmmmmmm.......mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmm...mmmmmmmmmmmmmmmm......mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmm...mmmmmmmmmmmmmmmmmm.mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmm...mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm",
"mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm"
};
