#
# This file is called by /etc/init.d/vdrdevel
#

#
# Defaults - don't touch, edit options for the VDR daemon in
# /etc/default/vdrdevel !!!
#

# Config-Directory
CFG_DIR="/var/lib/vdrdevel"

# Plugin-Directory
PLUGIN_DIR="/usr/lib/vdrdevel/plugins"

# Plugin Config-Directory
PLUGIN_CFG_DIR="/etc/vdrdevel/plugins"

# Plugin prefix
PLUGIN_PREFIX="libvdr-"

# Command-Hooks Directory
CMDHOOKSDIR="/usr/share/vdrdevel/command-hooks"

# Commmand executed on start, stop and editing of a recording
REC_CMD=/usr/lib/vdrdevel/vdrdevel-recordingaction

# Commmand executed by vdrdevel to shutdown the system
SHUTDOWNCMD="/etc/init.d/vdrdevel stop ; sleep 1 ; /sbin/shutdown -h now"

# EPG data file
EPG_FILE=/var/cache/vdrdevel/epg.data

# Default port for SVDRP
SVDRP_PORT=2001

# Enable / Disable vdrdevel daemon
ENABLED=0

# Enable / Disable automatic shutdown
ENABLE_SHUTDOWN=0

# Allow VDR to use NPTL (if available) - disabled by default
# (This has no effect on AMD64 machines.)
NONPTL=1


#
# Read configured options from /etc/default/vdrdevel
#
 
test -f /etc/default/vdrdevel && . /etc/default/vdrdevel
