#ifndef __SKINELCHI_I18N_H
#define __SKINELCHI_I18N_H

#include <vdr/i18n.h>

extern const tI18nPhrase Phrases[];

#endif // __SKINELCHI_I18N_H
