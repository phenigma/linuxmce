usr/share/vdr-plugin-#PACKAGE#/#PACKAGE#    var/lib/vdr/plugins/#PACKAGE#
