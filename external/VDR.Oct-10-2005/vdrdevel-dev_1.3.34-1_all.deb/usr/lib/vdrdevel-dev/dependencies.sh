#!/bin/sh
set -e

FIRST_VERSION=$(dpkg -s vdrdevel-dev | awk '/Version/ { print $2 }')
LAST_VERSION=$(echo $FIRST_VERSION | sed -e 's/-[^-]*$//')-9999

# Set conflicts with previous and next vdrdevel version in control
for p in $(dh_listpackages); do
    echo "vdrdevel:Depends=vdrdevel (>= $FIRST_VERSION)" >> debian/$p.substvars
    echo "vdrdevel:Conflicts=vdrdevel (>> $LAST_VERSION)" >> debian/$p.substvars
done
