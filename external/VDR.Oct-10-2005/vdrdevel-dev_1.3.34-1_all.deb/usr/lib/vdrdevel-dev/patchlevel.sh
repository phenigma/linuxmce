#!/bin/sh
set -e
case "$*" in
    "make")
        # scan patches in 00list and write to patchlevel file
        echo -n "Patches: "
        for p in $(grep "^[[:space:]]*opt-[0-9][0-9]_" debian/patches/00list | cut -d"_" -f2-); do
            echo -n "$p "
            if [ -z "$PATCHES" ]; then
                PATCHES="$p"
            else
                PATCHES="$PATCHES $p"
            fi
        done
        echo
        echo "vdrdevel:Patchlevel=$PATCHES" > patchlevel
        ;;
    "clean")
        # remove patchlevel file
        rm -f patchlevel
        ;;
    "subst")
        # read patchlevel file and write contents to *.substvars
        if [ -r patchlevel ]; then
            # main vdrdevel package
            PATCHES=$(cat patchlevel)
        else
            # vdrdevel-plugin package
            PATCHES=$(cat /usr/include/vdrdevel/patchlevel)
        fi
        # write *.substvars only if patchlevel not empty
        if [ "$PATCHES" != "vdrdevel:Patchlevel=" ]; then
            # scan control for packages
            for p in $(dh_listpackages); do
                echo "$PATCHES" >> debian/$p.substvars
            done
        fi
        ;;
    *)
        echo >&2 "$0: script expects make|clean|subst as argument"
        exit 1
        ;;
esac
exit 0
