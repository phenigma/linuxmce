#include <sys/types.h>
#include <pci/pci.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/io.h>
#include <netinet/in.h>
#include <linux/ppp_defs.h>
#include <pthread.h>
#include <time.h>
#include <termios.h>
#include <math.h>

#define NEED_PCI_IDS
#include <linux/zaptel.h>
#include "zapata-raddiag/zap.h"
#include "zapata-raddiag/zapinternal.h"

static float tones[4];
static int amps[4];
static ZAP *zaps[4];
static char resets[4];
static pthread_t threadid[4];
static pthread_mutex_t zaplock = PTHREAD_MUTEX_INITIALIZER;

#define	MW 22755.0

float emph[] = {300.0,502.0,1004.0,2004.0,3004.0} ;
int emphi[] = {38,64,129,257,385};

float blimits[] = 
   {310.0,350.0,430.0,470.0,495.0,535.0,445.0,485.0,365.0,405.0} ;

float dlimits[] = 
   {705.0,745.0,665.0,705.0,415.0,455.0,200.0,240.0,120.0,160.0} ;

float plimits[] = 
   {125.0,155.0,240.0,280.0,480.0,520.0,705.0,745.0,740.0,780.0} ;

static double steptofreq(int step)
{
	return((double)((float)step * (8000.0 / 1024.0)));
}

static void *zap_thread(void *this)
{
int 	n = (int) this,ipfft[NFFTSQRT + 2],i;
char fname[100];
float	a,t;
char	r,dofft;
double afft[(NFFT + 1) * 2 + 1],wfft[NFFT * 5 / 2];
	sprintf(fname,"/dev/zap/%d",n + 1);
	zaps[n] = zap_open(fname,0);  /* open for blocking I/O */
	if (!zaps[n])
	{
		fprintf(stderr,"Cannot open Zap channel %s\n",fname);
		exit(255);
	}
	for(;;)
	{
		pthread_mutex_lock(&zaplock);
		a = amps[n];
		t = tones[n];
		r = resets[n];
		dofft = 0;
		memset(afft,0,sizeof(double) * 2 * (NFFT + 1));
		if (zaps[n]->fftindex >= NFFT) 
		{
			for(i = 0; i < NFFT; i++)
			{
				afft[i * 2] = (double)(zaps[n]->fftbuf[i] + 32768) / (double)65536.0;
			}
			dofft = 1;
			zaps[n]->fftindex = 0;
			memset(zaps[n]->fftbuf,0,sizeof(short) * NFFT);
		}
		resets[n] = 0;
		pthread_mutex_unlock(&zaplock);
		if (r)
		{
			zaps[n]->fftindex = 0;
			memset(zaps[n]->fftbuf,0,sizeof(short) * NFFT);
		}
		if (dofft)
		{
			double ftot = 0.0, ffreq = 0.0, fmax = 0.0;
			int ifreq = 0;
			dofft = 0;
			ipfft[0] = 0;
			cdft(NFFT * 2,-1,afft,ipfft,wfft);

			for(i = 1; i < NFFT/2; i++)
			{
				double ftmp;
				ftmp = (afft[i * 2] * afft[i * 2]) + 
				    (afft[i * 2 + 1] * afft[i * 2 + 1]);
				ftot += ftmp;
				if (ftmp > fmax)
				{
					fmax = ftmp;
					ifreq = i;
				}
			}

			for(i = 1; i < NFFT/2; i++)
			{

				double ftmp;
				ftmp = (afft[i * 2] * afft[i * 2]) + 
				    (afft[i * 2 + 1] * afft[i * 2 + 1]);
				if ((i >= ifreq - 2) && (i <= ifreq + 2)) 
				{
					ffreq += ftmp;
				} 

			}
			zaps[n]->fftavg = sqrt(ftot) / (double) (NFFT / 2);
			zaps[n]->fftifreq = ifreq;
			ffreq = sqrt(ffreq) / (double) (NFFT / 2);
			zaps[n]->fftsinad = 20 * log10(ffreq / (zaps[n]->fftavg - ffreq));
		}
		if ((a < 1.0) || (t < 1.0))
		{
			if (zap_silence(zaps[n],800,ZAP_DTMFINT) == -1)
			{
				zap_close(zaps[n]);
				exit(255);
			}
		}
		else
		{
			if (zap_arbtone(zaps[n],t,800,ZAP_DTMFINT,a) == -1)
			{
				zap_close(zaps[n]);
				exit(255);
			}
		}
		while(zap_getevent(zaps[n]) > 0);
	}
}


static void atest(float freq, int *errs)
{
int	 n,m;

	printf("\n\nTesting analog channels at %.f Hz\n",freq);
	for(n = 0; n < 4; n++)
	{
		float f1;

		printf("\n\nTesting channel %d Receive (%d Send)...\n",n + 1,(n ^ 1) + 1);
		for(m = 0; m < 4; m++)
		{
			if (m == (n ^ 1))
			{
				amps[m] = MW;
				tones[m] = 1004.0;
			}
			else
			{
				amps[m] = 0.0;
				tones[m] = 0.0;
			}
		}
		for(m = 0; m < 6; m++)
		{
			int i;

			pthread_mutex_lock(&zaplock);
			for(i = 0; i < 4; i++) resets[i] = 1;
			pthread_mutex_unlock(&zaplock);
			usleep(500000);
		}
		for(m = 0; m < 4; m++)
		{
			f1 = (zaps[m]->fftavg * 32768.0) / 26.03;
			if (m != n)
			{
				if (f1 > 4.0)
				{
					printf("Too much level on quiet channel %d (%.2f mV), should be < 4.0 mV\n",m + 1,f1);
					errs[m]++;
				}
			}
			else
			{
				if (zaps[n]->fftifreq != 129)
				{
					printf("Reading wrong freq (%.f Hz) on channel %d (under test), should be 1007.8 Hz\n",steptofreq(zaps[n]->fftifreq),n + 1);
					errs[m]++;
				}
				if ((f1 < 420.0) || (f1 > 450.0))
				{
					printf("Level on channel %d (under test) out of range (%.2f mV),\n",m + 1,f1);
					printf("    Should be between 420 mV and 450 mV (Ideally 436 mV)\n");
					errs[m]++;
				}
				if (zaps[n]->fftsinad < 20.0)
				{
					printf("SINAD too low (%.2f DB) on channel %d (under test), should be at least 20.0 DB\n",zaps[n]->fftsinad,n + 1);
					errs[m]++;
				}
			}

#if	0
			printf("%d %.1f Hz:  %.fmV(%.02f DBm/%.02f DBm SINAD)\n",zaps[n]->fftifreq,steptofreq(zaps[n]->fftifreq),f1,
				log10(f1/436.0) * 20,zaps[n]->fftsinad);
#endif
		}
	}
	return;
}



int main(int argc, char *argv[])
{
int n,m,inited;
int channel;
unsigned char byte1,byte2;
pthread_attr_t attr;
struct termios t,t0;
extern FILE *zaplogfp;
struct zt_radio_param r;
struct zt_radio_stat rs;
float *limp;

	for(n = 0; n < 4; n++)
	{
		amps[n] = 0;
		tones[n] = 0;
	        pthread_attr_init(&attr);
	        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		pthread_create(&threadid[n],&attr,zap_thread,(void *) n);
	}

	tcgetattr(fileno(stdin),&t0);
	for(;;)
	{
		char str[80];
		int errs[4];

		limp = NULL;
		tcsetattr(fileno(stdin),TCSANOW,&t0);
		printf("Menu:\r\n\n");
		printf("(All Levels (receive) are in VRMS referenced to TP(X)5 for each channel\n");
		printf("1 - 1004Hz, 2 - 204Hz, 3 - 300Hz, 4 - 404Hz, 5 - 502Hz  (436mV, 0DBm for all)\n");
		printf("6 - 1502Hz, 7 - 2004Hz, 8 - 3004Hz (436mV, 0DBm for all)\n");
		printf("9 - 138mv (-10 DBm @ 900Hz), 0 - 44mv (-20 DBm @ 900Hz)\n");
		printf("t - test normal channel, p - test pre-emphasis, d - test de-emphasis\n");
		printf("b - test both pre-emphasis and de-emphasis together\n");
		printf("c - Test cable pinout, h - (help) instructions for testing\n");
		printf("q,x - exit program\r\n\n");
		printf("Enter your selection:");
		fflush(stdout);
		fgets(str,sizeof(str) - 1,stdin);
		if (isupper(str[0])) str[0] = tolower(str[0]);
		switch (str[0])
		{
		    case 'x':
		    case 'q':
			exit(0);
		    case '1':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 1000.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '2':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 204.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '3':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 304.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '4':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 404.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '5':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 504.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '6':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 1502.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '7':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 2004.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '8':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW;
				tones[n] = 3004.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '9':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW / 3.162277;
				tones[n] = 900.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case '0':
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = MW / 10.0;
				tones[n] = 900.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		    case 't':  /* test */
			for(n = 0; n < 4; n++)
			{
				errs[n] = 0;
			}
			atest(1004.0,errs);
			atest(300.0,errs);
			atest(3004.0,errs);
			printf("\r\nTesting digital signals.....\r\n\n");
			/* now we do digital I/O testing */
			/* first we release all UIO;s and put them both in input mode */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_EXTRXTONE;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				r.radpar = ZT_RADPAR_REMMODE;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				r.radpar = ZT_RADPAR_UIOMODE;
				r.data = 3;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
			}
			/* check to make sure everything reads back hi */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (r.data != 3)
				{
					printf("Initial input from UIO is not high on channel %d\n",n + 1);
					errs[n]++;
				}
			}
			/* now, we put A's in output, B's in input */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIOMODE;
				r.data = 2;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* output low to UIOA's */
				r.radpar = ZT_RADPAR_UIODATA;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
			}
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (r.data != 0)
				{
					printf("First (0) input from UIOB is not low (%d) on channel %d\n",r.data,n + 1);
					errs[n]++;
				}
			}
			/* now set the A output to hi */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				r.data = 1;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
			}
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (r.data != 3)
				{
					printf("Second (1) input from UIOB is not hi on channel %d\n",n + 1);
					errs[n]++;
				}
			}
			/* now, we put B's in output, A's in input */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIOMODE;
				r.data = 1;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* output low to UIOA's */
				r.radpar = ZT_RADPAR_UIODATA;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
			}
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (r.data != 0)
				{
					printf("First (0) input from UIOA is not low (%d) on channel %d\n",r.data,n + 1);
					errs[n]++;
				}
			}
			/* now set the B output to hi */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				r.data = 2;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
			}
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIODATA;
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (r.data != 3)
				{
					printf("Second (1) input from UIOA is not hi on channel %d\n",n + 1);
					errs[n]++;
				}
			}
			for(n = 0; n < 4; n++)
			{
				for(m = 0; m < 4; m++)
				{
					r.radpar = ZT_RADPAR_UIODATA;
					if (m == n) r.data = 2; else r.data = 0;
					if (ioctl(zaps[m]->fd,ZT_RADIO_SETPARAM,&r))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
				}
				for(m = 0; m < 4; m++)
				{
					r.radpar = ZT_RADPAR_UIODATA;
					if (ioctl(zaps[m]->fd,ZT_RADIO_GETPARAM,&r))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
					if (((m == (n ^ 1)) && (!r.data)) ||
						((m != (n ^ 1)) && (r.data & 1)))
					{
						printf("Walking bit in wrong state (%d) on channel %d/%d\n",r.data,m + 1,n + 1);
						errs[m]++;
					}
				}
			}			
			/* now, we put B's and A's in output */
			for(n = 0; n < 4; n++)
			{
				r.radpar = ZT_RADPAR_UIOMODE;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* output high to all */
				r.radpar = ZT_RADPAR_UIODATA;
				r.data = 3;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* set to ignore CTCSS */
				r.radpar = ZT_RADPAR_IGNORECT;
				r.data = 1;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* set Not to ignore COR */
				r.radpar = ZT_RADPAR_IGNORECOR;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* set Not to invert COR */
				r.radpar = ZT_RADPAR_INVERTCOR;
				r.data = 0;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* set to medium low threshold */
				r.radpar = ZT_RADPAR_CORTHRESH;
				r.data = 1;
				if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				/* un-set PTT (if any) */
				m = ZT_RINGOFF;
				if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
				{
					perror("Cannot send ioctl 1");
					exit(255);
				}
			}
			usleep(200000);
			/* Check for COR showing hi */
			for(n = 0; n < 4; n++)
			{
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETSTAT,&rs))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (!(rs.radstat & ZT_RADSTAT_RXCOR))
				{
					printf("COR in wrong initial state (%d) on channel %d\n",rs.radstat & ZT_RADSTAT_RXCOR,n + 1);
					errs[n]++;
				}
			}
			/* now, we assert PTT and see if COR goes low */
			for(n = 0; n < 4; n++)
			{
				/* un-set PTT (if any) */
				m = ZT_OFFHOOK;
				if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
				{
					perror("Cannot send ioctl 2");
					exit(255);
				}
			}
			usleep(200000);
			/* Check for COR showing low */
			for(n = 0; n < 4; n++)
			{
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETSTAT,&rs))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (rs.radstat & ZT_RADSTAT_RXCOR)
				{
					printf("COR in wrong second state (%d) on channel %d\n",rs.radstat & ZT_RADSTAT_RXCOR,n + 1);
					errs[n]++;
				}
			}
			for(n = 0; n < 4; n++)
			{
				for(m = 0; m < 4; m++)
				{

					int p;

					if (m == n) p = ZT_OFFHOOK; else p = ZT_RINGOFF;
					if (ioctl(zaps[m]->fd,ZT_HOOK,&p))
					{
						perror("Cannot send ioctl 3");
					}
				}
				usleep(200000);
				for(m = 0; m < 4; m++)
				{
					zap_flushevent(zaps[m]);
					if (ioctl(zaps[m]->fd,ZT_RADIO_GETSTAT,&rs))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
					if (((m == (n ^ 1)) && (rs.radstat & ZT_RADSTAT_RXCOR)) ||
						((m != (n ^ 1)) && (!(rs.radstat & ZT_RADSTAT_RXCOR))))
					{
						printf("Walking COR state wrong (%d) on channel %d/%d\n",rs.radstat & ZT_RADSTAT_RXCOR,m + 1,n + 1);
						errs[m]++;
					}
				}
			}			
			usleep(200000);
			printf("Testing CTCSS decoders...\r\n\n");
			/* assert PTT's so we can test CTCSS */
			for(n = 0; n < 4; n++)
			{
				/* un-set PTT (if any) */
				m = ZT_OFFHOOK;
				if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
				{
					perror("Cannot send ioctl 2");
					exit(255);
				}
				amps[n] = MW;
				tones[n]= 1004.0;
			}
			usleep(200000);
			for(m = 0; m < 6; m++)
			{
				int i;

				for(n = 0; n < 4; n++) zap_flushevent(zaps[n]);
				pthread_mutex_lock(&zaplock);
				for(i = 0; i < 4; i++) resets[i] = 1;
				pthread_mutex_unlock(&zaplock);
				usleep(500000);
			}
			for(n = 0; n < 4; n++)
			{
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETSTAT,&rs))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (!(rs.radstat & ZT_RADSTAT_RXCT))
				{
					printf("Not Receiving CTCSS tone on channel %d\n",n + 1);
					errs[n]++;
				}
			}
			/* now, De-assert PTT's to be nice */
			for(n = 0; n < 4; n++)
			{
				/* un-set PTT (if any) */
				m = ZT_RINGOFF;
				if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
				{
					perror("Cannot send ioctl 2");
					exit(255);
				}
			}
			usleep(200000);
			for(n = 0; n < 4; n++)
			{
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETSTAT,&rs))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (rs.radstat & ZT_RADSTAT_RXCT)
				{
					printf("Still Receiving CTCSS tone (where we shouldnt) on channel %d\n",n + 1);
					errs[n]++;
				}
			}

			printf("\n\n");
			for(n = 0; n < 4; n++)
			{
				zap_flushevent(zaps[n]);
				if (!errs[n])
					printf("Channel %d Passed!!\n",n + 1);
				else
					printf("Channel %d Failed with %d errors!!\n",n + 1,errs[n]);
			}
			printf("\n\n");
			continue;
		    case 'b':  /* test both pre-emphasis and de-emphasis */
			limp = blimits;
			/* fall thru intentionally */
		    case 'd':  /* test de-emphasis */
			if (!limp) limp = dlimits;
			/* fall thru intentionally */
		    case 'p':  /* test pre-emphasis */
			if (!limp) limp = plimits;
			for(n = 0; n < 4; n++)
			{
				errs[n] = 0;
			}
			for(m = 0;m < 5; m++)
			{
				printf("\r\n\nTesting at %.f Hz...\r\n\n",emph[m]);
				for(n = 0; n < 4; n++)
				{
					amps[n] = MW;
					tones[n] = emph[m];
				}
				for(n = 0; n < 6; n++)
				{
					int i;

					pthread_mutex_lock(&zaplock);
					for(i = 0; i < 4; i++) resets[i] = 1;
					pthread_mutex_unlock(&zaplock);
					usleep(500000);
				}
				for(n = 0; n < 4; n++)
				{
					float f1 = (zaps[n]->fftavg * 32768.0) / 26.03;
	
					if (zaps[n]->fftifreq != emphi[m])
					{
						printf("Reading wrong freq (%.f Hz) on channel %d (under test), should be %.2f Hz\n",steptofreq(zaps[n]->fftifreq),n + 1,(float)emphi[m] * 7.8125);
						errs[n]++;
					}
					if ((f1 < limp[m * 2]) || (f1 > limp[(m * 2) + 1]))
					{
						printf("Level on channel %d (under test) out of range (%.2f mV),\n",n + 1,f1);
						printf("    Should be between %.2f mV and %.2f mV\n",limp[m * 2],limp[(m * 2) + 1]);
						errs[n]++;
					}
					if (zaps[n]->fftsinad < 20.0)
					{
						printf("SINAD too low (%.2f DB) on channel %d (under test), should be at least 20.0 DB\n",zaps[n]->fftsinad,n + 1);
						errs[n]++;
					}
				}
			}

			printf("\n\n");
			for(n = 0; n < 4; n++)
			{
				zap_flushevent(zaps[n]);
				if (!errs[n])
					printf("Channel %d Passed!!\n",n + 1);
				else
					printf("Channel %d Failed with %d errors!!\n",n + 1,errs[n]);
			}
			printf("\n\n");
			continue;
		    case 'c': /* show test cable pinout */
			printf("Special Test Cable Pinout:\n\n");
			printf("Side 1           Side 2\n");
			printf("  1                7\n");
			printf("  2                5\n");
			printf("  3                6\n");
			printf("  4                4\n");
			printf("  5                2\n");
			printf("  6                3\n");
			printf("  7                1\n");
			printf("  8                8\n");
			printf("\nAlso, put a 100K 1/4 W resistor between pins\n");
			printf("2 and 3 of each connector.\n\n");
			continue;
		    default:
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++)
			{
				amps[n] = 10000.0;
				tones[n] = 1000.0;
				resets[n] = 1;
			}
			pthread_mutex_unlock(&zaplock);
			break;
		}
		tcgetattr(fileno(stdin),&t);
		cfmakeraw(&t);
		t.c_cc[VTIME] = 10;
		t.c_cc[VMIN] = 0;
		tcsetattr(fileno(stdin),TCSANOW,&t);
		inited = 0;
		for(;;)
		{
			int c = getc(stdin);
			if (c > 0) break;
			if (!zaps[0]) continue;
			if (!zaps[1]) continue;
			if (!zaps[2]) continue;
			if (!zaps[3]) continue;
			if (!inited)
			{
				for(n = 0; n < 4; n++)
				{
					/* set not to ignore CTCSS */
					r.radpar = ZT_RADPAR_IGNORECT;
					r.data = 0;
					if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
					/* set to invert COR */
					r.radpar = ZT_RADPAR_INVERTCOR;
					r.data = 1;
					if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
					/* set to not ignore COR */
					r.radpar = ZT_RADPAR_IGNORECOR;
					r.data = 0;
					if (ioctl(zaps[n]->fd,ZT_RADIO_SETPARAM,&r))
					{
						perror("Cannot send ioctl");
						exit(255);
					}
					usleep(10000);
					/* set PTT to generate CTCSS tone */
					m = ZT_OFFHOOK;
					if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
					{
						perror("Cannot send ioctl 1");
						exit(255);
					}
				}
				usleep(500000);
			}
			inited = 1;
			for(n = 0; n < 4; n++)
			{
				float f1 = (zaps[n]->fftavg * 32768.0) / 26.03;
				printf("%d: %.fmV(%.02f DBm/%.02f DBm SINAD)",n + 1,f1,
					log10(f1/436.0) * 20,zaps[n]->fftsinad);
				if (ioctl(zaps[n]->fd,ZT_RADIO_GETSTAT,&rs))
				{
					perror("Cannot send ioctl");
					exit(255);
				}
				if (!(rs.radstat & ZT_RADSTAT_RXCT))
					printf(" ");
				else printf("*");
				if (!(n & 1)) printf(" | "); else printf("\r\n");
			}
			printf("\r\n");
			fflush(stdout);
			pthread_mutex_lock(&zaplock);
			for(n = 0; n < 4; n++) resets[n] = 1;
			pthread_mutex_unlock(&zaplock);
		}
		/* un-set PTT (if any) */
		m = ZT_RINGOFF;
		for(n = 0; n < 4; n++)
		{
			if (ioctl(zaps[n]->fd,ZT_HOOK,&m))
			{
				perror("Cannot send ioctl 1");
				exit(255);
			}
		}
	}

}



