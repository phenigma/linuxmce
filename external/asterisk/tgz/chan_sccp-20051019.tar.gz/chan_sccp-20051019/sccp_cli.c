/*
 * (SCCP*)
 *
 * An implementation of Skinny Client Control Protocol (SCCP)
 *
 * Sergio Chersovani (mlists@c-net.it)
 *
 * Reworked, but based on chan_sccp code.
 * The original chan_sccp driver that was made by Zozo which itself was derived from the chan_skinny driver.
 * Modified by Jan Czmok and Julien Goodwin
 *
 * This program is free software and may be modified and
 * distributed under the terms of the GNU Public License.
 */

#include "config.h"
#include "chan_sccp.h"
#include "sccp_cli.h"
#include "sccp_indicate.h"
#include "sccp_utils.h"
#include "sccp_device.h"
#include "sccp_channel.h"
#include <asterisk/cli.h>

/* ------------------------------------------------------------ */

static int sccp_reset_restart(int fd, int argc, char * argv[]) {
  sccp_moo_t * r;
  sccp_device_t * d;

  if (argc != 3)
    return RESULT_SHOWUSAGE;

  d = sccp_device_find_byid(argv[2]);

  if (!d) {
    ast_cli(fd, "Can't find device %s\n", argv[2]);
    return RESULT_SUCCESS;
  }

  REQ(r, Reset);
  r->msg.Reset.lel_resetType = htolel((!strcasecmp(argv[1], "reset")) ? SKINNY_DEVICE_RESET : SKINNY_DEVICE_RESTART);
  sccp_dev_send(d, r);

  ast_cli(fd, "%s: Reset request sent to the device\n", argv[2]);
  return RESULT_SUCCESS;

}

/* ------------------------------------------------------------ */

static int sccp_show_device(int fd, int argc, char * argv[]) {
	sccp_device_t * d;
	sccp_speed_t * k;
	sccp_line_t * l;
	char pref_buf[128];
	char cap_buf[512];
	
	if (argc != 4)
		return RESULT_SHOWUSAGE;

	d = sccp_device_find_byid(argv[3]);
	if (!d) {
		ast_cli(fd, "Can't find settings for device %s\n", argv[3]);
		return RESULT_SUCCESS;
	}
	ast_mutex_lock(&d->lock);
	ast_codec_pref_string(&d->codecs, pref_buf, sizeof(pref_buf) - 1);
	ast_getformatname_multiple(cap_buf, sizeof(cap_buf), d->capability),
	
	ast_cli(fd, "Current settings for selected Device\n");
	ast_cli(fd, "------------------------------------\n\n");
	ast_cli(fd, "MAC-Address        : %s\n", d->id);
	ast_cli(fd, "Registration state : %s(%d)\n", skinny_registrationstate2str(d->registrationState), d->registrationState);
	ast_cli(fd, "Description        : %s\n", d->description);
	ast_cli(fd, "Config Phone Type  : %s\n", d->config_type);
	ast_cli(fd, "Skinny Phone Type  : %s(%d)\n", skinny_devicetype2str(d->skinny_type), d->skinny_type);
	ast_cli(fd, "Autologin          : %s\n", d->autologin);
	ast_cli(fd, "Image Version      : %s\n", d->imageversion);
	ast_cli(fd, "Capabilities       : %s\n", cap_buf);
	ast_cli(fd, "Codecs preference  : %s\n", pref_buf);
	ast_cli(fd, "DND                : %s\n", (d->dnd) ? "Enabled" : "Disabled");
	ast_cli(fd, "Can Transfer       : %s\n", (d->transfer) ? "Yes" : "No");
	ast_cli(fd, "Can Park           : %s\n", (d->park) ? "Yes" : "No");
	if (d->lastCallEndTime) { ast_cli(fd, "Last CallEndTime   : %d\n", (int)(d->lastCallEndTime)); };
	l = d->lines;
	if (l) {
		ast_cli(fd, "\nLines\n");
		ast_cli(fd, "%-4s: %-20s %-20s\n", "id", "name" , "label");
		ast_cli(fd, "------------------------------------\n");
		while (l) {
			ast_cli(fd, "%4d: %-20s %-20s\n", l->instance, l->name , l->label);
			l = l->next_on_device;
		}
	}
	k = d->speed_dials;
	if (k) {
		ast_cli(fd, "\nSpeedials\n");
		ast_cli(fd, "%-4s: %-20s %-20s\n", "id", "name" , "number");
		ast_cli(fd, "------------------------------------\n");
		while (k) {
			ast_cli(fd, "%4d: %-20s %-20s\n", k->instance, k->name , k->ext);
			k = k->next;
		}
	}
	ast_mutex_unlock(&d->lock);
	return RESULT_SUCCESS;
}

/* ------------------------------------------------------------ */


static struct ast_cli_entry cli_reset = {
  { "sccp", "reset", NULL },
  sccp_reset_restart,
  "Reset an SCCP device",
  "Usage: sccp reset <deviceId>\n"
};

static struct ast_cli_entry cli_restart = {
  { "sccp", "restart", NULL },
  sccp_reset_restart,
  "Reset an SCCP device",
  "Usage: sccp restart <deviceId>\n"
};

/* ------------------------------------------------------------ */

static int sccp_show_channels(int fd, int argc, char * argv[]) {
  sccp_channel_t * c;

  ast_cli(fd, "ID    LINE       DEVICE           AST STATE        SCCP STATE       CALLED     \n");
  ast_cli(fd, "===== ========== ================ ================ ================ ========== \n");

  ast_mutex_lock(&GLOB(channels_lock));
  c = GLOB(channels);
  while(c) {
   ast_cli(fd, "%.5d %-10s %-16s %-16s %-16s %-10s\n",
      c->callid,
      c->line->name,
      c->line->device->description,
      (c->owner) ? ast_state2str(c->owner->_state) : "No channel",
      sccp_indicate2str(c->state),
      c->calledPartyNumber);
   c = c->next;
  }
  ast_mutex_unlock(&GLOB(channels_lock));
  return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_show_channels = {
  { "sccp", "show", "channels", NULL },
  sccp_show_channels,
  "Show all SCCP channels",
  "Usage: sccp show channel\n",
};

/* ------------------------------------------------------------ */

static int sccp_show_devices(int fd, int argc, char * argv[]) {
  sccp_device_t * d;
  char iabuf[INET_ADDRSTRLEN];

  ast_cli(fd, "NAME             ADDRESS         MAC              CALLID          \n");
  ast_cli(fd, "================ =============== ================ ================\n");

  ast_mutex_lock(&GLOB(devices_lock));
  d = GLOB(devices);
  while(d) {
    ast_cli(fd, "%-16s %-15s %-16s\n",// %-10s %-16s %c%c %-10s\n",
      d->description,
      (d->session) ? ast_inet_ntoa(iabuf, sizeof(iabuf), d->session->sin.sin_addr) : "--",
      d->id
    );
    d = d->next;
  }
  ast_mutex_unlock(&GLOB(devices_lock));
  return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_show_devices = {
  { "sccp", "show", "devices", NULL },
  sccp_show_devices,
  "Show all SCCP Devices",
  "Usage: sccp show devices\n"
};

/* ------------------------------------------------------------ */

static int sccp_show_lines(int fd, int argc, char * argv[]) {
	sccp_line_t * l = NULL;
	sccp_channel_t * c = NULL;
	sccp_device_t * d = NULL;
	char cap_buf[512];

	ast_cli(fd, "NAME             DEVICE           MWI  Chs  Active Channel\n");
	ast_cli(fd, "================ ================ ==== ==== =================================================\n");

	ast_mutex_lock(&GLOB(lines_lock));
	l = GLOB(lines);

	while (l) {
		ast_mutex_lock(&l->lock);
		c = NULL;
		d = l->device;
		if (d) {
    		ast_mutex_lock(&d->lock);
			c = d->active_channel;
			ast_mutex_unlock(&d->lock);
		}

		if (!c || (c->line != l))
		c = NULL;
		memset(&cap_buf, 0, sizeof(cap_buf));
    	if (c && c->owner)
			ast_getformatname_multiple(cap_buf, sizeof(cap_buf),  c->owner->nativeformats);

		ast_cli(fd, "%-16s %-16s %-4s %-4d %-10s %-10s %-16s %-10s\n",
			l->name,
			(l->device) ? l->device->id : "--",
			(l->hasMessages) ? "ON" : "OFF",
			l->channelCount,
			(c) ? sccp_indicate2str(c->state) : "--",
			(c) ? skinny_calltype2str(c->calltype) : "",
			(c) ? ( (c->calltype == SKINNY_CALLTYPE_OUTBOUND) ? c->calledPartyName : c->callingPartyName ) : "",
			cap_buf);

		ast_mutex_unlock(&l->lock);
		l = l->next;
  }

  ast_mutex_unlock(&GLOB(lines_lock));
  return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_show_lines = {
  { "sccp", "show", "lines", NULL },
  sccp_show_lines,
  "Show All SCCP Lines",
  "Usage: sccp show lines\n"
};

static int sccp_show_sessions(int fd, int argc, char * argv[]) {
	sccp_session_t * s = NULL;
	sccp_device_t * d = NULL;
	char iabuf[INET_ADDRSTRLEN];

	ast_cli(fd, "Socket     IP              KA   DEVICE          STATE          TYPE\n");
	ast_cli(fd, "========== =============== ==== =============== =============== ===============\n");

	ast_mutex_lock(&GLOB(sessions_lock));
	s = GLOB(sessions);

	while (s) {
		ast_mutex_lock(&s->lock);
		d = s->device;
		if (d)
			ast_mutex_lock(&d->lock);
		ast_cli(fd, "%-10d %-15s %-4d %-15s %-15s %-15s\n",
			s->fd,
			ast_inet_ntoa(iabuf, sizeof(iabuf), s->sin.sin_addr),
			(uint32_t)(time(0) - s->lastKeepAlive),
			(d) ? d->id : "--",
			(d) ? skinny_devicestate2str(d->state) : "--",
			(d) ? skinny_devicetype2str(d->skinny_type) : "--");
		if (d)
			ast_mutex_unlock(&d->lock);
		ast_mutex_unlock(&s->lock);
		s = s->next;
	}
	ast_mutex_unlock(&GLOB(sessions_lock));
	return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_show_sessions = {
  { "sccp", "show", "sessions", NULL },
  sccp_show_sessions,
  "Show All SCCP Sessions",
  "Usage: sccp show sessions\n"
};

static struct ast_cli_entry cli_show_device = {
  { "sccp", "show", "device", NULL },
  sccp_show_device,
  "Show SCCP Device Information",
  "Usage: sccp show device <deviceId>\n"
};

static char debug_usage[] =
"Usage: SCCP debug <level>\n"
"       Set the debug level of the sccp protocol from none (0) to high (10)\n";

static char no_debug_usage[] =
"Usage: SCCP no debug\n"
"       Disables dumping of SCCP packets for debugging purposes\n";

static int sccp_do_debug(int fd, int argc, char *argv[]) {
	int new_debug = 10;

	if ((argc < 2) || (argc > 3))
		return RESULT_SHOWUSAGE;

	if (argc == 3) {
		if (sscanf(argv[2], "%d", &new_debug) != 1)
			return RESULT_SHOWUSAGE;
		new_debug = (new_debug > 10) ? 10 : new_debug;
		new_debug = (new_debug < 0) ? 0 : new_debug;
	}

	ast_cli(fd, "SCCP debug level was %d now %d\n", GLOB(debug), new_debug);
	GLOB(debug) = new_debug;
	return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_do_debug = {
  { "sccp", "debug", NULL },
  sccp_do_debug,
  "Enable SCCP debugging",
  debug_usage };

static int sccp_no_debug(int fd, int argc, char *argv[]) {
	if (argc != 3)
		return RESULT_SHOWUSAGE;

	GLOB(debug) = 0;
	ast_cli(fd, "SCCP Debugging Disabled\n");
	return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_no_debug = {
  { "sccp", "no", "debug", NULL },
  sccp_no_debug,
  "Disable SCCP debugging",
  no_debug_usage };

static int sccp_do_reload(int fd, int argc, char *argv[]) {
	ast_cli(fd, "SCCP configuration reload not implemented yet! use unload and load.\n");
	return RESULT_SUCCESS;
}

static char reload_usage[] =
"Usage: sccp reload\n"
"       Reloads SCCP configuration from sccp.conf (It will close all active connections)\n";

static struct ast_cli_entry cli_reload = {
  { "sccp", "reload", NULL },
  sccp_do_reload,
  "SCCP module reload",
  reload_usage };

static char version_usage[] =
"Usage: SCCP show version\n"
"       Show the SCCP channel version\n";

static int sccp_show_version(int fd, int argc, char *argv[]) {
	ast_cli(fd, "SCCP channel version: %s\n", SCCP_VERSION);
	return RESULT_SUCCESS;
}

static struct ast_cli_entry cli_show_version = {
  { "sccp", "show", "version", NULL },
  sccp_show_version,
  "SCCP show version",
  version_usage };

void sccp_register_cli(void) {
  ast_cli_register(&cli_show_channels);
  ast_cli_register(&cli_show_devices);
  ast_cli_register(&cli_show_lines);
  ast_cli_register(&cli_show_sessions);
  ast_cli_register(&cli_show_device);
  ast_cli_register(&cli_show_version);
  ast_cli_register(&cli_reload);
  ast_cli_register(&cli_restart);
  ast_cli_register(&cli_reset);
  ast_cli_register(&cli_do_debug);
  ast_cli_register(&cli_no_debug);
}

void sccp_unregister_cli(void) {
  ast_cli_unregister(&cli_show_channels);
  ast_cli_unregister(&cli_show_devices);
  ast_cli_unregister(&cli_show_lines);
  ast_cli_unregister(&cli_show_sessions);
  ast_cli_unregister(&cli_show_device);
  ast_cli_unregister(&cli_show_version);
  ast_cli_unregister(&cli_reload);
  ast_cli_unregister(&cli_restart);
  ast_cli_unregister(&cli_reset);
  ast_cli_unregister(&cli_do_debug);
  ast_cli_unregister(&cli_no_debug);
}
