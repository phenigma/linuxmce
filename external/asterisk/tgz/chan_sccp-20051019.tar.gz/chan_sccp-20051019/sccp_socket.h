#ifndef __SCCP_SOCKET_H
#define __SCCP_SOCKET_H

void * sccp_socket_thread(void * ignore);
void sccp_session_close(sccp_session_t * s);


#endif
