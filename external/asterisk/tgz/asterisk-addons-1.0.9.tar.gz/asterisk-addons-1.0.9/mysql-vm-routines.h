/*
 * to use mysql-vm-routines, set USE_MYSQL_VM_INTERFACE to 1
 * in asterisk/apps/Makefile , then put this file into 
 * asterisk/apps/ and (re)build asterisk.
*/

MYSQL *dbhandler=NULL;
ast_mutex_t mysqllock;
char dbuser[80];
char dbpass[80];
char dbhost[80];
char dbname[80];

static int mysql_login(void)
{
	ast_verbose( VERBOSE_PREFIX_3 "Logging into database with user %s, password %s, and database %s\n", dbuser, dbpass, dbname);

	dbhandler=mysql_init(NULL);
	if (!mysql_real_connect(dbhandler, dbhost[0] ? dbhost : NULL, dbuser, dbpass, dbname, 0, NULL, 0)) {
		ast_log(LOG_WARNING, "Error Logging into database\n");
		return(-1);
	}
	ast_mutex_init(&mysqllock);
	return(0);
}

static void mysql_logout(void)
{
	mysql_close(dbhandler);
}

#ifdef USESQLVM
static struct ast_vm_user *find_user(struct ast_vm_user *ivm, char *context, char *mailbox)
{
	MYSQL_RES *result;
	MYSQL_ROW rowval;
	MYSQL_FIELD *fields;
	int numFields, i;
	char query[240];
	char options[160] = "";
	struct ast_vm_user *retval;

	retval=malloc(sizeof(struct ast_vm_user));

	if (retval) {
		memset(retval, 0, sizeof(struct ast_vm_user));
		populate_defaults(retval);	
		retval->attach=-1;
		retval->alloced=1;
		retval->next=NULL;
		if (mailbox) {
			strcpy(retval->mailbox, mailbox);
		}
		if (context) {
			strcpy(retval->context, context);
		} else {
			strcpy(retval->context, "default");
			context = "default";
		}

		/* We should at this point have the context and retval->context else we free retval and return NULL */
		if (*retval->context) {
			snprintf(query, sizeof(query)-1, "SELECT password,fullname,email,pager,options FROM users WHERE context='%s' AND mailbox='%s'", context, mailbox);
		} else {
			free(retval);
			return(NULL);
		}
		ast_mutex_lock(&mysqllock);
		mysql_query(dbhandler, query);
		if ((result=mysql_store_result(dbhandler))!=NULL) {
			if ((rowval=mysql_fetch_row(result))!=NULL) {
				numFields=mysql_num_fields(result);
				fields=mysql_fetch_fields(result);
				for (i=0; i<numFields; i++) {
					if (rowval[i]) {
						if (!strcmp(fields[i].name, "password")) {
							strcpy(retval->password, rowval[i]);
						} else if (!strcmp(fields[i].name, "fullname")) {
							strcpy(retval->fullname, rowval[i]);
						} else if (!strcmp(fields[i].name, "email")) {
							strcpy(retval->email, rowval[i]);
						} else if (!strcmp(fields[i].name, "pager")) {
							strcpy(retval->pager, rowval[i]);
						} else if (!strcmp(fields[i].name, "options")) {
							strncpy(options, rowval[i], sizeof(options) - 1);
							apply_options(retval, options);
						}
					}
				}
				mysql_free_result(result);
				ast_mutex_unlock(&mysqllock);
				return(retval);
			} else {
				mysql_free_result(result);
				ast_mutex_unlock(&mysqllock);
				free(retval);
				return(NULL);
			}
		}
		ast_mutex_unlock(&mysqllock);
		free(retval);
	}
	return(NULL);
}
static void vm_change_password(struct ast_vm_user *vmu, char *password)
{
	char query[400];

	if (*vmu->context) {
		snprintf(query, sizeof(query)-1, "UPDATE users SET password='%s' WHERE context='%s' AND mailbox='%s' AND password='%s'", password, vmu->context, vmu->mailbox, vmu->password);
	} else {
		/* Lets be specific here since we can have for example exten 123 in diffrent contexts.
		   This has the ability to update/change passwords for all users with mailbox 123. */
		snprintf(query, sizeof(query)-1, "UPDATE users SET password='%s' WHERE mailbox='%s' AND password='%s' AND context='default'", password, vmu->mailbox, vmu->password);
	}
	ast_mutex_lock(&mysqllock);
	mysql_query(dbhandler, query);
	strcpy(vmu->password, password);
	ast_mutex_unlock(&mysqllock);
}

static void reset_user_pw(char *context, char *mailbox, char *password)
{
	char query[320];

	if (context) {
		snprintf(query, sizeof(query)-1, "UPDATE users SET password='%s' WHERE context='%s' AND mailbox='%s'", password, context, mailbox);
	} else {
		/* Lets be specific here since we can have for example exten 123 in diffrent contexts.
		   This has the ability to reset passwords for all users with mailbox 123. */
		snprintf(query, sizeof(query)-1, "UPDATE users SET password='%s' WHERE mailbox='%s' AND context='default'", password, mailbox);
	}
	ast_mutex_lock(&mysqllock);
	mysql_query(dbhandler, query);
	ast_mutex_unlock(&mysqllock);
}
#endif

static int sql_init(void)
{
	static int res;
	if ((res=mysql_login())) {
		return(res);
	}
	return 0;
}

static void sql_close(void)
{
	mysql_logout();
}
