#include <apihelp.h>

void *astapi_run_app(void *tmp_in) {
	struct app_container *tmp = (struct app_container *) tmp_in;
	asterisk_run_app(tmp->chan,tmp->app,tmp->data,0);
	return NULL;
}

