#ifndef __RES_PERL_H
#define __RES_PERL_H
#include <asterisk/file.h>
#include <asterisk/logger.h>
#include <asterisk/channel.h>
#include <asterisk/pbx.h>
#include <asterisk/module.h>
#include <asterisk/astdb.h>
#include <asterisk/cli.h>
#include <asterisk/logger.h>
#include <asterisk/options.h>
#include <asterisk/image.h>
#include <asterisk/say.h>
#include <asterisk/app.h>
#include <asterisk/dsp.h>
#include <asterisk/musiconhold.h>
#include <asterisk.h>
#include <arpa/inet.h>
#include <asterisk/ast_expr.h>
#include <asterisk/callerid.h>
#include <asterisk/cdr.h>
#include <asterisk/channel.h>
#include <asterisk/channel_pvt.h>
#include <asterisk/cli.h>
#include <asterisk/config.h>
#include <asterisk/config_pvt.h>
#include <asterisk/file.h>
#include <asterisk/linkedlists.h>
#include <asterisk/lock.h>
#include <asterisk/logger.h>
#include <asterisk/manager.h>
#include <asterisk/md5.h>
#include <asterisk/module.h>
#include <asterisk/options.h>
#include <asterisk/pbx.h>
#include <asterisk/utils.h>
#include <asterisk/say.h>
#include <asterisk/term.h>
#include <asterisk/features.h>
#include <EXTERN.h>
#include <perl.h>
#include <sys/time.h>

EXTERN_C void xs_init (pTHX);
void *perl_thread(void *ignore);
AV *eval_some_perl(PerlInterpreter *perl,char *func,char *arg);
int can_run_nochan(char *test);
int process_perl_return_value(struct ast_channel *chan,char *ret);

#ifdef HAVE_RES_CONFIG
struct ast_config *perl_config(char *file, struct ast_config *new_config_s,struct ast_category **new_cat_p,struct ast_variable **new_v_p,int recur
#ifdef PRESERVE_COMMENTS
							   ,struct ast_comment_struct *acs
#endif

							   );

#endif

void launch_perl_thread(char *function);

#endif
