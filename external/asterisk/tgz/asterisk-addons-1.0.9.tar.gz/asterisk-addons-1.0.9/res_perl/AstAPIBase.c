#include <res_perl.h>
#include <apihelp.h>
#include <linux/zaptel.h>
#include <sys/ioctl.h>
#define CONF_SIZE 160


AST_MUTEX_DEFINE_STATIC(modlock);

#ifdef POST_10
#define ast_set_read_format_a(chan,fmt) ast_set_read_format(chan,fmt,0);
#define ast_set_write_format_a(chan,fmt) ast_set_write_format(chan,fmt,0);

#else
#define ast_set_read_format_a(chan,fmt) ast_set_read_format(chan,fmt);
#define ast_set_write_format_a(chan,fmt) ast_set_write_format(chan,fmt);
#endif



void asterisk_log(char *log,char *msg) {
	
	if(!strcmp(log,"LOG_EVENT"))
		ast_log(LOG_EVENT,msg);

	else if(!strcmp(log,"LOG_NOTICE"))
		ast_log(LOG_NOTICE,msg);


	else if(!strcmp(log,"LOG_WARNING"))
		ast_log(LOG_WARNING,msg);


	else if(!strcmp(log,"LOG_ERROR"))
		ast_log(LOG_ERROR,msg);


	else if(!strcmp(log,"LOG_VERBOSE"))
		ast_log(LOG_VERBOSE,msg);

}

struct ast_channel *asterisk_get_channel_by_name(char *name) {
	struct ast_channel *c=NULL;
	ast_mutex_lock(&modlock);
	if((c=ast_get_channel_by_name_locked(name)))
		ast_mutex_unlock(&c->lock);
	ast_mutex_unlock(&modlock);
	return c;
}



int asterisk_chanlist(int fd)
{
#define FORMAT_STRING  "%15s  (%-10s %-12s %-4d) %7s %-12s  %-15s\n"
#define FORMAT_STRING2 "%15s  (%-10s %-12s %-4s) %7s %-12s  %-15s\n"
	struct ast_channel *c=NULL;
	int numchans = 0;
	c = ast_channel_walk_locked(NULL);
	ast_cli(fd, FORMAT_STRING2, "Channel", "Context", "Extension", "Pri", "State", "Appl.", "Data");
	while(c) {
		ast_log(LOG_WARNING,"WTF %s",c->name);
		ast_cli(fd, FORMAT_STRING, c->name, c->context, c->exten, c->priority, ast_state2str(c->_state),
				c->appl ? c->appl : "(None)", c->data ? ( strlen(c->data) ? c->data : "(Empty)" ): "(None)");
		numchans++;
		ast_mutex_unlock(&c->lock);
		c = ast_channel_walk_locked(c);
	}
	ast_cli(fd, "%d active channel(s)\n", numchans);
	return RESULT_SUCCESS;
}


int asterisk_chan_priority(struct ast_channel *chan,int pri) {
	
	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return 0;
	}

	if(pri != -1)
		chan->priority = pri;
 
	return chan->priority;
}

int asterisk_run_app(struct ast_channel *chan,char *app_name,char *data,int fork) {

	pthread_attr_t attr;
	struct app_container *tmp;
	struct ast_app *app;
	
	
	app = (struct ast_app *) pbx_findapp(app_name);
	if (app) {
		if(! fork)
			return pbx_exec(chan, app, data, 1);
		else {
			tmp = malloc(sizeof(struct app_container));
			if (tmp) {
				memset(tmp, 0, sizeof(struct app_container));
				strncpy(tmp->app, app_name, sizeof(tmp->app) - 1);
				strncpy(tmp->data, data, sizeof(tmp->data) - 1);
				tmp->chan = chan;
				pthread_attr_init(&attr);
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
				if (ast_pthread_create(&tmp->t, &attr, astapi_run_app, tmp)) {
					//ast_log(LOG_WARNING, "Unable to spawn execute thread on %s: %s\n", chan->name, strerror(errno));
					free(tmp);
					return 0;
				}
			}
			else {
				ast_log(LOG_ERROR, "Out of memory :(\n");
				return -1;
			}
		}
	}
	else 
		ast_log(LOG_WARNING, "Could not find application (%s)\n", app_name);
	return -1;
}


int asterisk_exec(struct ast_channel *chan,char *app_name,char *data) {
	
	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return 0;
	}

	return asterisk_run_app(chan,app_name,data,0);

}


int asterisk_control_streamfile(struct ast_channel *chan, char *file, char *fwd, char *rev, char *stop, char *pause, int skipms) {
	return ast_control_streamfile(chan,file,fwd,rev,stop,pause,skipms);
}

int asterisk_answer(struct ast_channel *chan) {
	int res=0;

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	if (chan->_state != AST_STATE_UP) {
		/* Answer the chan */
		res = ast_answer(chan);
	}
	
	return res;
}


int asterisk_waitfordigit(struct ast_channel *chan,int to) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	return ast_waitfordigit(chan,to);
}



int asterisk_sendtext(struct ast_channel *chan,char *text) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	return ast_sendtext(chan,text);
}

int asterisk_recvchar(struct ast_channel *chan, int to) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	return ast_recvchar(chan,to);
}

int asterisk_tddmode(struct ast_channel *chan,char *mode) {
	int x;

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	if (!strncasecmp(mode,"on",2)) x = 1; else x = 0;
	if (!strncasecmp(mode,"mate",4)) x = 2;
	if (!strncasecmp(mode,"tdd",3)) x = 1;
	return ast_channel_setoption(chan,AST_OPTION_TDD,&x,sizeof(char),0);
}

int asterisk_sendimage(struct ast_channel *chan, char *img_name) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	return ast_send_image(chan, img_name);
}

int asterisk_streamfile(struct ast_channel *chan,char *file, char *digits,long sample_offset) {
	int res;
	struct ast_filestream *fs;
	long max_length;
	int input;
	char blank[2] = "";
	

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	if(!file) {
		ast_log(LOG_WARNING, "No Filename!\n");
		return -1;
	}
	
	if(!digits) {
		digits=blank;
	}
	

	res = ast_waitfor(chan, -1);
	input = ast_waitfordigit(chan,100);
	if(input < 0)
		return -1;
	
	fs = (struct ast_filestream *) ast_openstream(chan, file, chan->language);
	if(!fs){
		ast_log(LOG_WARNING, "Unable to open %s\n", file);
		return -1;
	}
	ast_seekstream(fs, 0, SEEK_END);
	max_length = ast_tellstream(fs);
	ast_seekstream(fs, sample_offset, SEEK_SET);
	res = ast_applystream(chan, fs);
	res = ast_playstream(fs);
	if (res) {
		return -1;
	}
	res = ast_waitstream(chan,digits);
	sample_offset = (chan->stream)?ast_tellstream(fs):max_length;
	ast_stopstream(chan);
	return res;

}

int asterisk_saynumber(struct ast_channel *chan,int num) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	return  ast_say_number(chan, num,AST_DIGIT_ANY, chan->language,(char *) NULL);
}

int asterisk_saydigits(struct ast_channel *chan,char *data) {
	return ast_say_digit_str(chan, data,AST_DIGIT_ANY, chan->language);
}

char *asterisk_getdata(struct ast_channel *chan,char *filename,int max,int timeout ) {
	int res;
	char data[1024] = {""};
	char *ptr;

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return NULL;
	}


	res = ast_app_getdata(chan, filename, data, max, timeout);
	if(!res) {
		ptr=data;
		return ptr ? ptr : "";
	}
	else
		return "hangup";
}

int asterisk_setcontext(struct ast_channel *chan,char *context) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	strncpy(chan->context, context, sizeof(chan->context)-1);
	return 1;
}
	
int asterisk_setextension(struct ast_channel *chan,char *exten) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
	

	strncpy(chan->exten, exten, sizeof(chan->exten)-1);
	return 0;
}

int asterisk_setpriority(struct ast_channel *chan,int pri) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	chan->priority = pri - 1;
	return 1;
}
		

int asterisk_recordfile(struct ast_channel *chan,char *filename,char *format,char *digits,int timeout,int silence,int beep) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
	

	struct ast_filestream *fs;
	struct ast_frame *f;
	struct timeval tv, start;
	long sample_offset = 0;
	int res = 0;
	int ms=timeout;	

	struct ast_dsp *sildet=NULL;         /* silence detector dsp */
	int totalsilence = 0;
	int dspsilence = 0;

	int gotsilence = 0;             /* did we timeout for silence? */

	int rfmt=0;


	if (silence > 0) {
		rfmt = chan->readformat;
		res = ast_set_read_format_a(chan, AST_FORMAT_SLINEAR);
		if (res < 0) {
			ast_log(LOG_WARNING, "Unable to set to linear mode, giving up\n");
			return -1;
		}
		sildet = (struct ast_dsp *) ast_dsp_new();
		if (!sildet) {
			ast_log(LOG_WARNING, "Unable to create silence detector :(\n");
			return -1;
		}
		ast_dsp_set_threshold(sildet, 256);
	}

	if (beep)
		res = ast_streamfile(chan, "beep", chan->language);
	if (!res)
		res = ast_waitstream(chan, digits);
	if (!res) {
		fs = ast_writefile(filename, format, NULL, O_CREAT | O_WRONLY | (sample_offset ? O_APPEND : 0), 0, 0644);
		if (!fs) {
			res = -1;
			return res;
		}
		
		chan->stream = fs;
		ast_applystream(chan,fs);
		/* really should have checks */
		ast_seekstream(fs, sample_offset, SEEK_SET);
		ast_truncstream(fs);
		
		gettimeofday(&start, NULL);
		gettimeofday(&tv, NULL);
		while ((ms < 0) || (((tv.tv_sec - start.tv_sec) * 1000 + (tv.tv_usec - start.tv_usec)/1000) < ms)) {
			res = ast_waitfor(chan, -1);
			if (res < 0) {
				ast_closestream(fs);
				return res;
			}
			f = ast_read(chan);
			if (!f) {
				ast_closestream(fs);
				return -1;
			}
			switch(f->frametype) {
			case AST_FRAME_DTMF:
				if (strchr(digits, f->subclass)) {
					/* This is an interrupting chracter */
					sample_offset = ast_tellstream(fs);
					ast_closestream(fs);
					ast_frfree(f);
					return 1;
						
				}
				break;
			case AST_FRAME_VOICE:
				ast_writestream(fs, f);
				/* this is a safe place to check progress since we know that fs
				 * is valid after a write, and it will then have our current
				 * location */
				sample_offset = ast_tellstream(fs);
				if (silence > 0) {
					dspsilence = 0;
					ast_dsp_silence(sildet, f, &dspsilence);
					if (dspsilence) {
						totalsilence = dspsilence;
					} else {
						totalsilence = 0;
					}
					if (totalsilence > silence) {
						/* Ended happily with silence */
						ast_frfree(f);
						gotsilence = 1;
						break;
					}
				}
				break;
			}
			ast_frfree(f);
			gettimeofday(&tv, NULL);
			if (gotsilence)
				break;
		}
			
		if (gotsilence) {
			ast_stream_rewind(fs, silence-1000);
			ast_truncstream(fs);
		}		
		ast_closestream(fs);
	} else
		
		if (silence > 0) {
			res = ast_set_read_format_a(chan, rfmt);
			if (res)
				ast_dsp_free(sildet);
		}

	return sample_offset;
}


int asterisk_autohangup(struct ast_channel *chan, int timeout) {


	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
	

	if (timeout < 0)
		timeout = 0;
	if (timeout)
		chan->whentohangup = time(NULL) + timeout;
	else
		chan->whentohangup = 0;

	return 1;
}

int asterisk_soft_hangup(struct ast_channel *chan) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	return ast_softhangup(chan,AST_SOFTHANGUP_EXPLICIT);
}

int asterisk_hangup(struct ast_channel *chan) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
	
	return ast_hangup(chan);
}

void asterisk_setcallerid(struct ast_channel *chan,char *callerid) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return;
	}


	ast_set_callerid(chan, callerid, 0);
}

int asterisk_channelstatus(struct ast_channel *chan) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	return chan->_state;
}

int asterisk_setvariable(struct ast_channel *chan,char *var, char *val) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	pbx_builtin_setvar_helper(chan, var, val);
	return 0;
}

char *asterisk_getvariable(struct ast_channel *chan, char *var) {
	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return NULL;
	}
	
	return (char *) pbx_builtin_getvar_helper(chan,var);
}

void asterisk_verbose(int level,char *msg) {
	char *prefix;

	switch (level) {
	case 4:
		prefix = VERBOSE_PREFIX_4;
		break;
	case 3:
		prefix = VERBOSE_PREFIX_3;
		break;
	case 2:
		prefix = VERBOSE_PREFIX_2;
		break;
	case 1:
		prefix = VERBOSE_PREFIX_1;
		break;
	case 0:
	default:
		prefix = "";
		break;
	}

	if (level <= option_verbose)
		ast_verbose("%s%s", prefix,msg);
	

}

char *asterisk_dbget(struct ast_channel *chan,char *db, char *name) {
	int res;
	char tmp[256] = {""};
	char *ptr;


	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return NULL;
	}
	

	res = ast_db_get(db, name, tmp, sizeof(tmp));
	ptr = tmp;

	if (ptr)
		return ptr;

	return "";

}

int asterisk_dbput(struct ast_channel *chan,char *db, char *name,char *data) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}

	return ast_db_put(db, name, data);
}

int asterisk_dbdel(struct ast_channel *chan,char *db, char *name) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
	
	return ast_db_del(db,name);
}

int asterisk_dbdeltree(struct ast_channel *chan,char *family,char *keytree) {


	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}


	if (keytree && strlen(keytree))
		return ast_db_deltree(family,keytree);
	else
		return ast_db_deltree(family, NULL);

}

void asterisk_moh_start(struct ast_channel *chan,char *moh) {


	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return;
	}


	if (moh && strlen(moh))
		ast_moh_start(chan,moh);
	else
		ast_moh_start(chan, NULL);

}



void asterisk_moh_stop(struct ast_channel *chan) {

	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return;
	}
	

	ast_moh_stop(chan);
}


int asterisk_bridge_call(struct ast_channel *chan, struct ast_channel *peer, int allowredir_in, int allowredir_out, int allowdisconnect) {
	struct ast_bridge_config config;
  
	if(!chan || !peer) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
  
	memset(&config,0,sizeof(struct ast_bridge_config));
	config.allowredirect_in = allowredir_in;
	config.allowredirect_out = allowredir_out;
	config.allowdisconnect_in = allowdisconnect;
	config.allowdisconnect_out = allowdisconnect;
	return ast_bridge_call(chan,peer,&config);
	
}



int asterisk_bridge_call_long(struct ast_channel *chan, struct ast_channel *peer, int allowredir_in, int allowredir_out, int allowdisconnect_in, int allowdisconnect_out,long timelimit,long play_warning,long warning_freq,char *warning_sound,char *end_sound,char *start_sound) {
	struct ast_bridge_config config;
  
	if(!chan || !peer) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return -1;
	}
  
	memset(&config,0,sizeof(struct ast_bridge_config));
	config.allowredirect_in = allowredir_in;
	config.allowredirect_out = allowredir_out;
	config.allowdisconnect_in = allowdisconnect_in;
	config.allowdisconnect_out = allowdisconnect_out;
	config.timelimit = timelimit;
	config.play_warning = play_warning;
	config.warning_freq = warning_freq;
	config.warning_sound = warning_sound;
	config.end_sound = end_sound;
	config.start_sound = start_sound;
	return ast_bridge_call(chan,peer,&config);
	
}


struct ast_channel *asterisk_request_and_dial(char *type,char *data,int format,char *callerid, int timeout) {
	int reason;
	struct ast_channel *chan;
	chan = ast_request_and_dial(type,AST_FORMAT_ULAW, data, timeout, &reason,callerid);
	return chan;
}


int asterisk_manager_command(int fd,char *cmd) {
	return ast_cli_command(fd, cmd);
}

int asterisk_cli(int fd,char *cmd) {
	ast_cli(fd,cmd);
	return 0;
}

int asterisk_best_format(struct ast_channel *chan) {
	return ast_best_codec(chan->nativeformats);
}

void asterisk_set_read_format(struct ast_channel *chan,int format) {
	ast_set_read_format_a(chan,format);
}


void asterisk_set_write_format(struct ast_channel *chan,int format) {
	ast_set_write_format_a(chan,format);
}

void asterisk_set_best_read_format(struct ast_channel *chan) {
	ast_set_read_format_a(chan, ast_best_codec(chan->nativeformats));
}


void asterisk_set_best_write_format(struct ast_channel *chan) {
	ast_set_write_format_a(chan, ast_best_codec(chan->nativeformats));
}


struct ast_channel *asterisk_request(int format,char *type,char *data,char *callerid) {
	struct ast_channel *chan=NULL;
	chan = ast_request(type, format, data);
	if (callerid && strlen(callerid))
		ast_set_callerid(chan, callerid, 1);

	return chan;
}


int asterisk_dial(struct ast_channel *chan,char *data,int timeout) {
	int res=0,state=0;
	struct ast_frame *f;
	
	if (!ast_call(chan, data, 0)) {
		while(timeout && (chan->_state != AST_STATE_UP)) {
			res = ast_waitfor(chan, timeout);
			if (res < 0) {
				/* Something not cool, or timed out */
				break;
			}
			/* If done, break out */
			if (!res)
				break;
			if (timeout > -1)
				timeout = res;
			f = ast_read(chan);
			if (!f) {
				state = AST_CONTROL_HANGUP;
				res = 0;
				break;
			}
			if (f->frametype == AST_FRAME_CONTROL) {
				if (f->subclass == AST_CONTROL_RINGING)
					state = AST_CONTROL_RINGING;
				else if ((f->subclass == AST_CONTROL_BUSY) || (f->subclass == AST_CONTROL_CONGESTION)) {
					state = f->subclass;
					ast_frfree(f);
					break;
				} else if (f->subclass == AST_CONTROL_ANSWER) {
					state = f->subclass;
					ast_frfree(f);
					break;
				} else {
					ast_log(LOG_NOTICE, "Don't know what to do with control frame %d\n", f->subclass);
				}
			}
			ast_frfree(f);
		}
	} else
		ast_log(LOG_NOTICE, "Unable to dial channel %s/%s\n", chan->type, (char *)data);

	if (chan && res <= 0) {
		if (!chan->cdr) {
			chan->cdr = ast_cdr_alloc();
			if (chan->cdr)
				ast_cdr_init(chan->cdr, chan);
		}
		if (chan->cdr) {
			char tmp[256];
			sprintf(tmp, "%s/%s",chan->type,(char *)data);
			ast_cdr_setapp(chan->cdr,"Dial",tmp);
			ast_cdr_update(chan);
			ast_cdr_start(chan->cdr);
			ast_cdr_end(chan->cdr);
			/* If the cause wasn't handled properly */
			if (ast_cdr_disposition(chan->cdr,chan->hangupcause))
				ast_cdr_failed(chan->cdr);
		} else
			ast_log(LOG_WARNING, "Unable to create Call Detail Record\n");
		ast_hangup(chan);
		chan = NULL;
	}


	return res;
}


void asterisk_waitfor(struct ast_channel *chan,int wait) {
	if(!chan) {
		ast_log(LOG_WARNING, "No Channel!\n");
		return ;
	}

	ast_waitfor(chan,wait);
}


int asterisk_make_compatible(struct ast_channel *chan,struct ast_channel *peer) {

	if(!chan || ! peer) {
		ast_log(LOG_WARNING, "No Channels!\n");
		return -1;
	}

	return ast_channel_make_compatible(chan, peer);
	
}


void asterisk_wait_for_control(struct ast_channel *chan,int subclass,int timeout) {
	struct ast_frame *f;
	time_t start,now;

	time(&now);
	start = now;

	if(!chan) {
		ast_log(LOG_WARNING, "No Channels!\n");
		return;
	}

	while(ast_waitfor(chan, -1) > -1) {
		time(&now);

		f = ast_read(chan);
		if (!f)
			break;
		
		if (f->frametype == AST_FRAME_CONTROL) {

			if (! subclass || f->subclass == subclass) {
				break;
			}
		}
		
		ast_log(LOG_WARNING,"debug: %d->%d\n",f->frametype,f->subclass);


		if((now-start) > timeout)
			break;

	}
	
}

