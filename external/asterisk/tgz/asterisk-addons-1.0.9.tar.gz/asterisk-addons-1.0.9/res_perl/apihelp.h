#ifndef _APIHELP_H
#define _APIHELP_H
#include <pthread.h>

struct app_container {
    char app[256];
    char data[256];
    struct ast_channel *chan;
    pthread_t t;
};


void *astapi_run_app(void *tmp_in);
int asterisk_run_app(struct ast_channel *chan,char *app_name,char *data,int fork);
#endif
