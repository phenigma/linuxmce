/*
 * Asterisk	  -- A telephony toolkit for Linux.
 *
 * res_perl.c -- A Module To Incoperate Perl Into Asterisk.
 * 
 * Copyright (C) 2003, Anthony Minessale 
 *
 * Anthony Minessale <anthm@cylynx.com>
 *
 * This program is free software, distributed under the terms of
 * the GNU General Public License
 */

#define CSV_LOGUNIQUEID
#define CSV_LOGUSERFIELD

#include <res_perl.h>

#define RES_PERL_VERSION "1.0"
#define CREATE_STRING(name,size) char name[size];

// <PERL SPECIFIC MUMBO JUMBO>

static PerlInterpreter *global_perl;
static char *embedding[] = { "", "-e",""};
static STRLEN n_a;
static HV* PERL_CONFIG;
// </PERL SPECIFIC MUMBO JUMBO>

static char delim=129;

AST_MUTEX_DEFINE_STATIC(perl_lock);
AST_MUTEX_DEFINE_STATIC(users_lock);
static int reloading=0;
static int users=0;
int _unload_module(void);
int _load_module(void);

#ifdef HAVE_AST_CUST_CONFIG
static struct ast_config_reg reg1;
static int use_config=0;
#endif

static int use_switch=0;
static int use_cdr=0;
static int clone_on_config=0;

static void replace_delim(char *arg,char a,char b) {
	int i;
	for(i=0;i<strlen(arg);i++) {
		if(arg[i] == a)
			arg[i] = b;
	}
}

static char *get_hash_val(PerlInterpreter *my_perl,HV *hash,char *key) {
    SV *val;
    char *ret=NULL;
    if (hash) {
		val = *hv_fetch(hash,key,strlen(key),FALSE);
		if (val)
			ret = SvPV_nolen(val);
    }
    return ret;
}


static void init_perl(PerlInterpreter **new_perl) {
    char code[100];
    //ast_log(LOG_WARNING,"CREATING PERL INTREPRETER\n");
    *new_perl = perl_alloc();
    PERL_SET_CONTEXT(*new_perl);
    perl_construct(*new_perl);
    perl_parse(*new_perl, xs_init, 3, embedding, NULL);
    perl_run(*new_perl);
    sprintf(code,"use lib '%s/perl';package Asterisk::Embed;use asterisk_init;\n",ASTETCDIR);
    Perl_eval_pv(*new_perl,code, TRUE);
    return;
    
}


static void dest_perl(PerlInterpreter **old_perl) {
    if (*old_perl != NULL) {
		//ast_log(LOG_WARNING,"DESTROYING PERL INTREPRETER\n");
		perl_destruct(*old_perl);
		perl_free(*old_perl);
		*old_perl=NULL;
    }
}


static void users_inc() {
    ast_mutex_lock(&users_lock);
    users++;
    ast_mutex_unlock(&users_lock);
}

static void users_dec() {
    ast_mutex_lock(&users_lock);
    users--;
    if (users < 0)
		users = 0;
    ast_mutex_unlock(&users_lock);
}

static struct threadlist {
    char func[256];
    pthread_t thread;
    struct threadlist*next;
} *threads;


static char *tdesc = "Perl Interface";
static char *app = "Perl";
static char *synopsis = "Use Perl in Asterisk";
static char *descrip = "Use Perl in Asterisk";



STANDARD_LOCAL_USER;
LOCAL_USER_DECL;

static void list_threads(int fd) {
    struct threadlist *ptr;

    ast_cli(fd,"\n\nACTIVE THREADS:\n");
    for (ptr=threads;ptr;ptr=ptr->next) {
		if ((long) ptr->thread)
			ast_cli(fd,"thread %ld -> %s\n",(long) ptr->thread,ptr->func);
    }
    ast_cli(fd,"\n\n");
}





static void rem_thread(struct threadlist *tl) {
    struct threadlist *ptr,*prev;

    for (ptr=threads;ptr;ptr=ptr->next) {

		if ((long)ptr->thread == (long)tl->thread) {
			if (ptr==threads) {
				threads=NULL;
				break;
			} else {
				if (prev) {
					prev->next = ptr->next;
				}
			}
	    
		}

		prev=ptr;
    }
}

static void add_thread(struct threadlist *tl) {
    struct threadlist *ptr;

    if (threads)
		for (ptr=threads;ptr->next;ptr=ptr->next);

    if (ptr)
		ptr->next = tl;
    else
		threads = tl;

}


static void end_thread(char *thread_in) {
    struct threadlist *ptr;
    pthread_t thread;
    long thread_id;

    if (thread_in == NULL)
		thread_id=0;
    else 
		thread_id=atol(thread_in);
    
    
    for (ptr=threads;ptr;ptr=ptr->next) {
		if (((long) ptr->thread == thread_id) || thread_id==0) {
			thread = ptr->thread;
			ast_log(LOG_NOTICE,"Kill Thread: %ld\n",(long)ptr->thread);
			pthread_kill(thread,SIGQUIT);
			rem_thread(ptr);
		}

    }



}




void launch_perl_thread(char *function) {
    pthread_t thread;
    pthread_attr_t attr;
    int result;
    if (!function)
		return;

    result = pthread_attr_init(&attr);
    pthread_attr_setschedpolicy(&attr, SCHED_RR);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    result = ast_pthread_create(&thread, &attr,perl_thread,function);
    result = pthread_attr_destroy(&attr);

}



void *perl_thread(void *function) {
    AV *array;
    int x,i,exit;
    char *stringp,*func,*arg;
    pthread_t thread;
    struct threadlist tl;


    x = i = 0;
    exit = 1;
    ast_log(LOG_WARNING,"Started Thread\n");  

    stringp=strdup(function);
    func=strsep(&stringp,":");
    arg=strsep(&stringp,"\0");
    thread = pthread_self();
    tl.thread = thread;
    strncpy(tl.func,func,sizeof(tl.func));
    /* clone perl for this thread */
	PerlInterpreter *my_perl=perl_clone(global_perl,CLONEf_COPY_STACKS|CLONEf_KEEP_PTR_TABLE);

    add_thread(&tl);
    array=eval_some_perl(my_perl,func,arg);
    rem_thread(&tl);
    ast_log(LOG_WARNING,"%s is shutting down\n",(char *) func);
    ast_log(LOG_WARNING,"Ended Thread\n");
    dest_perl(&my_perl);
    return((void *) 1);
}


AV *eval_some_perl(PerlInterpreter *my_perl,char *func,char *arg) {
    char *callfunc;
	char *fmt = "eval{\n$SIG{QUIT} = sub {die q|SIGQUIT! Exit Requested.\n|};\nmy @args=split(chr 129,q`%s`);\nforeach (@args) {s/\\\\n/\\n/g};\n@%s=&Asterisk::Embed::%s(@args)};\nif($@) {Asterisk::Embed::asterisk_verbose(0,\"ERROR:\n$@\n\")\n};\n ";
	size_t size = (strlen(func) * 2) + strlen(arg) + strlen(fmt) + 128;
	callfunc=alloca(size);
    snprintf(callfunc,size,fmt,arg ? arg : "",func,func);
    PERL_SET_CONTEXT(my_perl);
    eval_pv(callfunc, TRUE);
    return get_av(func, FALSE);
    
}

int can_run_nochan(char *test) {
    static char *list[] = {"setvar","add_ext","include","thread"};
    int i=0;
    int ret=0;
    for (i=0;i<4;i++) {
		if (!strcmp(test,list[i])) {
			ret=1;
			break;
		}
    }
    return(ret);
}

int process_perl_return_value(struct ast_channel *chan,char *ret) {
    char *arg,*stringp,*func;

    if (!ret)
		return 0;




    stringp=strdup(ret);
    func=strsep(&stringp,":");
    arg=strsep(&stringp,"\0");

    if (func && arg) {


		ast_log(LOG_WARNING,"call function [%s]\n",func);

		if (func && ! chan && can_run_nochan(func) == 0) {
			ast_log(LOG_WARNING, "cannot use function [%s] from here,skipping...\n",func);
			return 1;
		}
		if (!strcmp(func,"thread")) {
			launch_perl_thread(arg);
		}
    }

    return 0;
}



static int perl_exec(struct ast_channel *chan, void *data)
{
    char *func;
    char *arg;
	char *info;
    char *stringp=NULL;
    char buf[2048];
    AV *array;
    int i;
    I32 array_size;
    char *rval;
    PerlInterpreter *my_perl;
    int retme=0;


    if (!data || !strlen(data)) {
		ast_log(LOG_WARNING, "Ignoring blank arg\n");
		return -1;
    }
    
    /* clone perl for this execution */
	my_perl=perl_clone(global_perl,CLONEf_COPY_STACKS|CLONEf_KEEP_PTR_TABLE);
    users_inc();

	info=ast_strdupa(data);
    stringp=info;
    func=strsep(&stringp,":");
    arg=strsep(&stringp,"\0");


    if (chan && chan->name && arg) {
		sprintf(buf,"%s%c%s",chan->name,':',arg);
		arg=buf + strlen(chan->name);
    } else if(chan && chan->name) {
		sprintf(buf,"%s",chan->name);
		arg=buf;
    } else {
		ast_log(LOG_WARNING,"No channel, sorry...\n");
		return -1;
    }


    ast_log(LOG_WARNING, "Calling Perl Sub [%s] [%s]\n",func,buf);
	replace_delim(arg,':',delim);

	array=eval_some_perl(my_perl,func,buf);

    if (array) {
		array_size = av_len(array) + 1;
		for (i = 0; i < array_size; i++) {
			rval = SvPV(*av_fetch(array, i, FALSE),n_a);
			retme = atoi(rval);
			if (! process_perl_return_value(chan,rval)) {
				users_dec();
				dest_perl(&my_perl);
				return retme;
			}
		}
    }

    users_dec();
    dest_perl(&my_perl);
    return(retme);
}		





static int perl_reload(int fd) {

    ast_log(LOG_WARNING, "This wont work yet\n");
    return 0;


    if (users) {
		ast_log(LOG_WARNING, "Too Busy for reload wait for %d users first.\n",users);
		return 0;
    }
    if (reloading) {
		ast_log(LOG_WARNING, "Not done reloading from last time yet!\n");
    }


    ast_mutex_lock(&perl_lock);
    reloading = 1;
    _unload_module();
    _load_module();
    reloading = 0;
    users = 0;
    ast_mutex_unlock(&perl_lock);

    return 0;
}



static int perl_cli(int fd, int argc, char *argv[]) {
    AV *array;
    int i;
    I32 array_size;
    char * rval;
    PerlInterpreter *my_perl = global_perl;
    char arg1[255],arg2[255];

    if (argv[1] && !strcmp(argv[1],"reload")) {
		perl_reload(fd);
		return 0;
    } else if(argv[1] && argv[2] && !strcmp(argv[1],"thread")) {
		launch_perl_thread(argv[2]);
		ast_cli(fd,"\n\n");
		return 0;
    } else if(argv[1] && !strcmp(argv[1],"threads")) {
		list_threads(fd);
		return 0;
    } else if(argv[1] && argv[2] && !strcmp(argv[1],"end")) {
		if (!strcmp(argv[2],"all"))
			end_thread(NULL);
		else 
			end_thread(argv[2]);
		ast_cli(fd,"OK\n\n");
		return 0;
    } else if(argv[1] && !strcmp(argv[1],"labotomy")) {
		dest_perl(&global_perl);
		init_perl(&global_perl);
		ast_cli(fd,"OK, One Flew Over The KooKoo's Nest!.....\n");
		return 0;
    } else if(argv[1] && !strcmp(argv[1],"call")) {
		if (!argv[2]) {
			ast_cli(fd,"\nusage perlcall <args>\n"); 
			return 0;
		}

		if (argv[2] && argv[3]) {
			strncpy(arg1,argv[2],255);
			strncpy(arg2,argv[3],255);
			replace_delim(arg1,':',delim);
			replace_delim(arg2,':',delim);
			array=eval_some_perl(my_perl,arg1,arg2);
		} else if(argv[2]) {
			strncpy(arg1,argv[2],255);
			replace_delim(arg1,':',delim);
			array=eval_some_perl(my_perl,arg1,"");
		}
		if (array) {
			array_size = av_len(array) + 1;
			for (i = 0; i < array_size; i++) {
				rval = SvPV(*av_fetch(array, i, FALSE),n_a);
				process_perl_return_value(NULL,rval);
			}
		}
	

		return 0;
    }

    if (argv[1])
		ast_cli(fd,"\nUnknown Command: %s\n",argv[1]);
    else 
		ast_cli(fd,"\nusage perl <command> <args>\n");

    return 0;
}

/* <SWITCH> */


static int perl_switch_handler(char *func,struct ast_channel *chan, char *context, char *exten, int priority, char *callerid, char *data,int clone) {

	AV *array;
	int array_size=0,i=0,ret=0;
	char args[256],*rval=NULL;
	PerlInterpreter *my_perl;
	if (clone) {
	    my_perl=perl_clone(global_perl,CLONEf_COPY_STACKS|CLONEf_KEEP_PTR_TABLE);
	} else {
	    my_perl = global_perl;
	}
	snprintf(args,sizeof(args),"%s:%s:%s:%s:%d:%s:%s",func,chan->name?chan->name:"nochan",context,exten,priority,callerid,data);
	replace_delim(args,':',delim);
	array=eval_some_perl(my_perl,"perl_switch_handler",args);
	if (array) {
	    array_size = av_len(array) + 1;
	    for (i = 0; i < array_size; i++) {
			rval = SvPV(*av_fetch(array, i, FALSE),n_a);
			ret = atoi(rval);
			if (ret >= 0)
				break;
	    }

	} else {
	    ret = 0;
	}

	if (clone)
	    dest_perl(&my_perl);

	return ret;
}

static int perl_switch_exists(struct ast_channel *chan, char *context, char *exten, int priority, char *callerid, char *data) {
    return perl_switch_handler("exists",chan,context,exten,priority,callerid,data,0);
}

static int perl_switch_canmatch(struct ast_channel *chan, char *context, char *exten, int priority, char *callerid, char *data) {
    return perl_switch_handler("canmatch",chan,context,exten,priority,callerid,data,0);
}

static int perl_switch_exec(struct ast_channel *chan, char *context, char *exten, int priority, char *callerid, int newstack, char *data) {
    return perl_switch_handler("exec",chan,context,exten,priority,callerid,data,1);
}

static int perl_switch_matchmore(struct ast_channel *chan, char *context, char *exten, int priority, char *callerid, char *data) {
    return perl_switch_handler("matchmore",chan,context,exten,priority,callerid,data,0);
}


static struct ast_switch perl_switch =
	{
		name:			"Perl",
		description:	"Perl Switch",
		exists:			perl_switch_exists,
		canmatch:		perl_switch_canmatch,
		exec:			perl_switch_exec,
		matchmore:		perl_switch_matchmore,
	};






/* </SWITCH> */

static struct ast_cli_entry  cli_perl = { { "perl", NULL }, perl_cli, "Perl", "Perl" };

int _unload_module(void) {
    
    if (use_switch) {
		ast_unregister_switch(&perl_switch);
    }

    if (use_cdr) {
		ast_cdr_unregister("perl");
    }


    eval_some_perl(global_perl,"shutdown","");
    end_thread(NULL);

    dest_perl(&global_perl);

    if (reloading)
		return 0;



#ifdef HAVE_AST_CUST_CONFIG
    if (use_config) {
		ast_log(LOG_NOTICE,"unloading perl config engine.\n");
		ast_cust_config_deregister(&reg1);
    }
#endif

    STANDARD_HANGUP_LOCALUSERS;
    ast_cli_unregister(&cli_perl);
    ast_unregister_application(app);
    return 0;

}


static int append_string(char *buf, char *s, int len)
{
    int pos = strlen(buf);
    int spos = 0;
    int error = 0;
    if (pos >= len - 4)
		return -1;
    error = -1;
    while (pos < len - 3) {
		if (!s[spos]) {
			error = 0;
			break;
		}
		buf[pos++] = s[spos];
		spos++;
    }
    buf[pos++] = delim;
    buf[pos++] = '\0';
    return error;
}

static int append_int(char *buf, int s, int len)
{
    char tmp[32];
    int pos = strlen(buf);
    snprintf(tmp, sizeof(tmp), "%d", s);
    if (pos + strlen(tmp) > len - 3)
		return -1;
    strncat(buf, tmp, len);
    pos = strlen(buf);
    buf[pos++] = delim;
    buf[pos++] = '\0';
    return 0;
}

static int append_long(char *buf, long s, int len)
{
    char tmp[32];
    int pos = strlen(buf);
    snprintf(tmp, sizeof(tmp), "%ld", s);
    if (pos + strlen(tmp) > len - 3)
		return -1;
    strncat(buf, tmp, len);
    pos = strlen(buf);
    buf[pos++] = delim;
    buf[pos++] = '\0';
    return 0;
}



static int append_tv_diff(char *buf,struct timeval *ended,struct timeval *started, int len)
{
    char tmp[32];
    int pos = strlen(buf);
    long elapsed = (((ended->tv_sec * 1000) + ended->tv_usec / 1000) - ((started->tv_sec * 1000) + started->tv_usec / 1000));  

    snprintf(tmp, sizeof(tmp), "%ld", elapsed);
    if (pos + strlen(tmp) > len - 3)
		return -1;
    strncat(buf, tmp, len);
    pos = strlen(buf);
    buf[pos++] = delim;
    buf[pos++] = '\0';
    return 0;
}

static int build_csv_record(char *buf, int len, struct ast_cdr *cdr)
{

    buf[0] = '\0';
    /* Account code */
	append_string(buf,"accountcode", len);
    append_string(buf, cdr->accountcode, len);
    /* Source */
	append_string(buf,"src", len);
    append_string(buf, cdr->src, len);
    /* Destination */
	append_string(buf,"dest", len);
    append_string(buf, cdr->dst, len);
    /* Destination context */
	append_string(buf,"destcontext", len);
    append_string(buf, cdr->dcontext, len);
    /* Caller*ID */
	append_string(buf,"callerid", len);
    append_string(buf, cdr->clid, len);
    /* Channel */
	append_string(buf,"chan", len);
    append_string(buf, cdr->channel, len);
    /* Destination Channel */
	append_string(buf,"destchan", len);
    append_string(buf, cdr->dstchannel, len);
    /* Last Application */
	append_string(buf,"lastapp", len);
    append_string(buf, cdr->lastapp, len);
    /* Last Data */
	append_string(buf,"lastapparg", len);
    append_string(buf, cdr->lastdata, len);
    /* Start Time */
	append_string(buf,"start_time", len);
    append_long(buf, cdr->start.tv_sec, len);
    /* Answer Time */
	append_string(buf,"answer_time", len);
    append_long(buf, cdr->answer.tv_sec, len);
    /* End Time */
	append_string(buf,"end_time", len);
    append_long(buf, cdr->end.tv_sec, len);
    /* Duration */
	append_string(buf,"duration", len);
    append_int(buf, cdr->duration, len);

    append_string(buf,"duration_ms", len);
    append_tv_diff(buf, &cdr->end,&cdr->start, len);


    /* Billable seconds */
	append_string(buf,"billable", len);
    append_int(buf, cdr->billsec, len);

    append_string(buf,"billable_ms", len);
    append_tv_diff(buf,&cdr->end,&cdr->answer, len);


    /* Disposition */
	append_string(buf,"disposition", len);
    append_string(buf, ast_cdr_disp2str(cdr->disposition), len);
    /* AMA Flags */
	append_string(buf,"amaflags", len);
    append_string(buf, ast_cdr_flags2str(cdr->amaflags), len);

#ifdef CSV_LOGUNIQUEID
    /* Unique ID */
	append_string(buf,"uniqueid",len);
    append_string(buf, cdr->uniqueid, len);
#endif
#ifdef CSV_LOGUSERFIELD
    /* append the user field */
	append_string(buf,"user",len);
    append_string(buf, cdr->userfield,len);	
#endif
    /* If we hit the end of our buffer, log an error */
	if (strlen(buf) < len - 5) {
	    /* Trim off trailing comma */
		buf[strlen(buf) - 1] = '\0';
	    return 0;
	}
    return -1;
}


static int perl_log(struct ast_cdr *cdr) {
    char buf[1024];
    PerlInterpreter *my_perl;
    
    my_perl=perl_clone(global_perl,CLONEf_COPY_STACKS|CLONEf_KEEP_PTR_TABLE);
    if (build_csv_record(buf,1024, cdr)) {
		ast_log(LOG_WARNING, "Unable to create CSV record in 1024 bytes.  CDR not recorded!\n");
    } else {
		eval_some_perl(my_perl,"perl_cdr",buf);
    }
    dest_perl(&my_perl);
    return 0;
}

#ifdef HAVE_AST_CUST_CONFIG
struct ast_config *perl_config(char *file, struct ast_config *new_config_s,struct ast_category **new_cat_p,struct ast_variable **new_v_p,int recur
#ifdef PRESERVE_COMMENTS
							   ,struct ast_comment_struct *acs
#endif

							   ) {

    PerlInterpreter *my_perl;

    if (clone_on_config)
		my_perl=perl_clone(global_perl,CLONEf_COPY_STACKS|CLONEf_KEEP_PTR_TABLE);
    else 
		my_perl = global_perl;
    
    struct ast_config *new;
    struct ast_variable *cur_v=NULL,*new_v;
    struct ast_category *cur_cat=NULL,*new_cat=NULL;
    char last[80];
    int cat_started=0;
    int var_started=0;
    AV *array;
    int i=0,ii=0;
    I32 array_size,vars_size;
    HV *hash;
    char *category=NULL;

    AV *vars;
    HV *varshash;
    SV *name,*var,*val,*tmp;
    
    if (file && !strcmp(file,"res_perl.conf"))
		return NULL; // cant configure myself

	if (new_config_s) {
	    new = new_config_s;
	    cat_started++;
	} else 
	    new = ast_new_config();
    
    last[0] = '\0';

    cat_started=0;
    var_started=0;

    cur_cat = *new_cat_p;
    cur_v = *new_v_p;

    if (cur_cat)
		cat_started=1;
    if (cur_v)
		var_started=1;
    
    array=eval_some_perl(my_perl,"perl_config",file);

    if (array) {
		array_size = av_len(array) + 1;
    } else {
		return NULL;
    }
    
    for (i = 0; i < array_size; i++) {
		tmp = *av_fetch(array, i, FALSE);
		if (!SvROK(tmp))
			continue ;
	
		hash = (HV*) SvRV(tmp);
		if (hash && SvTYPE(hash) == SVt_PVHV) {
			name = *hv_fetch(hash,"name",4,FALSE);
			vars = (AV*) SvRV(*hv_fetch(hash,"vars",4,FALSE));
	    
			if (name && strcmp(last,SvPV_nolen(name))) {
				// new cat
				category = SvPV_nolen(name);
				strcpy(last,category);
				new_cat = (struct ast_category *) ast_new_category(category);
		
				if (!cat_started) {
					cat_started++;
					new->root = new_cat;
					cur_cat=new->root;
				} else {
					cur_cat->next = new_cat;
					cur_cat = cur_cat->next;
				}
				var_started=0;
			}
	    

			if (name && vars && SvTYPE(vars) == SVt_PVAV) {
				if (vars)
					vars_size = av_len(vars) + 1;
				else
					return NULL;
				for (ii = 0; ii < vars_size; ii++) {
					varshash = (HV*) SvRV(*av_fetch(vars, ii, FALSE));
					if (varshash && SvTYPE(varshash) == SVt_PVHV) {
						var = *hv_fetch(varshash,"var",3,FALSE);
						val = *hv_fetch(varshash,"val",3,FALSE);
			
						if (category && var && val) {
							new_v = ast_new_variable(SvPV_nolen(var),SvPV_nolen(val));
							if (!var_started) {
								var_started++;
								cur_cat->root = new_v;
								cur_v = cur_cat->root;
							} else {
								cur_v->next = new_v;
								cur_v = cur_v->next;
							}


						}
					}
				}

		
			}
		}
    }
    if (!i)
		new = NULL;

    if (clone_on_config)
		dest_perl(&my_perl);
    
    return new;


}
#endif

int _load_module(void) {
    AV *array=NULL;
    int i=0,res=0;
    I32 array_size;
    char *rval;
    users = 0;
    PerlInterpreter *my_perl;


    if (global_perl == NULL)
		init_perl(&global_perl);



    /* perl has hard coded macros on my_perl, need it */
	my_perl = global_perl;

    array=eval_some_perl(global_perl,"startup","");
    if (array)
		array_size = av_len(array) + 1;
    else 
		return 0;

    for (i = 0; i < array_size; i++) {
		rval = SvPV(*av_fetch(array, i, FALSE),n_a);
		ast_verbose(VERBOSE_PREFIX_1 " == res_perl: startup function returned %s\n",rval);
		process_perl_return_value((struct ast_channel *) NULL,rval);
	
    }
    
    if (reloading)
		return 0;

    ast_cli_register(&cli_perl); 
    
    PERL_CONFIG = get_hv("Asterisk::Embed::PERL_CONFIG",0);
    if (PERL_CONFIG) {
#ifdef HAVE_AST_CUST_CONFIG

		if (hv_exists(PERL_CONFIG,"USE_CONFIG",strlen("USE_CONFIG"))) {
			rval = get_hash_val(my_perl,PERL_CONFIG,"USE_CONFIG");
			if (rval && ast_true(rval)) {
				use_config = 1;
				
				ast_log(LOG_NOTICE,"loading perl config engine.\n");
				memset(&reg1,0,sizeof(struct ast_config_reg));
				strcpy(reg1.name,"perl");
				reg1.func = perl_config;
				ast_cust_config_register(&reg1);
				
			} else 
				ast_log(LOG_NOTICE,"perl config engine disabled.\n");
			
		} else
			ast_log(LOG_NOTICE,"perl config engine disabled.\n");
		

#endif

		if (hv_exists(PERL_CONFIG,"CLONE_ON_CONFIG",strlen("CLONE_ON_CONFIG"))) {
			rval = get_hash_val(my_perl,PERL_CONFIG,"CLONE_ON_CONFIG");
			if (rval && ast_true(rval)) {
				ast_log(LOG_NOTICE, "Perl Option: CLONE_ON_CONFIG Activated..\n");
				clone_on_config=1;
			}
		}
	
		if (hv_exists(PERL_CONFIG,"USE_CDR",strlen("USE_CDR"))) {
			rval = get_hash_val(my_perl,PERL_CONFIG,"USE_CDR");
			if (rval && ast_true(rval)) {
				use_cdr = 1;
				res = ast_cdr_register("perl","Perl CDR", perl_log);
				if (res) 
					ast_log(LOG_ERROR, "Unable to register Perl CDR handling\n");
			} else
				ast_log(LOG_NOTICE, "Perl CDR Disabled.\n");
		} else 
			ast_log(LOG_NOTICE, "Perl CDR Disabled.\n");
	
		if (hv_exists(PERL_CONFIG,"USE_SWITCH",strlen("USE_SWITCH"))) {
			rval = get_hash_val(my_perl,PERL_CONFIG,"USE_SWITCH");
			if (rval && ast_true(rval)) {
				use_switch = 1;
				if (ast_register_switch(&perl_switch))
					ast_log(LOG_ERROR, "Unable to register Perl Switch\n");
				else
					ast_log(LOG_NOTICE, "Registering Perl Switch\n");
			} else
				ast_log(LOG_NOTICE, "Perl Switch Disabled.\n");
		} else
			ast_log(LOG_NOTICE, "Perl Switch Disabled.\n");
		
	
	} else
		ast_log(LOG_WARNING,"CONFIG HASH TABLE %%PERL_CONFIG NOT FOUND MANY FEATURES DISABLED!\n");

	return ast_register_application(app, perl_exec, synopsis, descrip);
}




char *description(void) {
    return tdesc;
}

int usecount(void) {
    int res;
    STANDARD_USECOUNT(res);
    return res;
}

char *key() {
    return ASTERISK_GPL_KEY;
}
