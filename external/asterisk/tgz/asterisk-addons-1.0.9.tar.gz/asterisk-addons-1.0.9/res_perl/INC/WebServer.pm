#!/usr/local/bin/perl
use IO::Socket;
use IO::Select;

use CGI;
use Data::Dumper;
our $server;
use IO::Handle;
our $finished = 0;

sub htdecode($;$) {
  my $urlin = shift;
  my $url = (ref $urlin) ? \$$urlin : \$urlin;
  $$url =~ s/%([0-9A-Z]{2})/chr hex $1/ieg;
  $$url;
}

sub genheads($@) {
  my $now = scalar gmtime() . "GMT";
  my $code = shift;
  my %chart = (500 => "HTTP/1.1 500 Server Error",
	       404 => "HTTP/1.1 404 Not Found",
	       200 => "HTTP/1.1 200 OK",
	       302 => "HTTP/1.1 302 Found",
	      );

  my @heads = ( $chart{$code} || $chart{404},
		"Date: $now",
		"Server: AsteriskWeb 1.0",
		"Accept-Ranges: bytes"
	      );
  if(!$_[0]) {
    return join("\n", (@heads,@_)) . "\n";
  }
  join("\n", (@heads,@_)) . "\n\n";
}







sub done() {
  asterisk_log("LOG_WARNING","WEB SERVER CLOSING DOWN\n");
  close LOG;
  $server->close();
  $server = $client = undef;

  $finished = 1;
}




my $select = IO::Select->new();
our %CGI_CODE = ();



sub webserver_eval_file($) {
  my $file = shift;
  my @st = stat "$file";
  return undef if(! @st);
  my $code;
  my $mod;
  my $key = $file;
  $key =~ s/\W//g;
  


  if(exists $CGI_CODE{$key}) {
    ($code,$mod) = @{$CGI_CODE{$key}};
    if(! $mod || ($st[9] > $mod)) {
      asterisk_log("LOG_WARNING","$file expired.\n");
      $code = undef;
    }
  }

  if(!$code) {
    open(I,$file) or return undef;
    $/=undef;
    $code = <I>;
    close I;
    $/ = "\n";
    asterisk_log("LOG_WARNING","Loaded $file\n");
    eval {
      eval $code;
      return undef if(! \&ast_cgi);
      $CGI_CODE{$key} = [\&ast_cgi,time];
    };
  }


  return $CGI_CODE{$key}->[0];
  
}



sub web_server() {

  my $server_port = "8080";
  $server = IO::Socket::INET->new(LocalPort => $server_port,
				  Type      => SOCK_STREAM,
				  Proto    => "tcp",
				  Reuse     => 1,
				  Listen    => 50 ) # or SOMAXCONN
    or die "Couldn't be a tcp server on port $server_port : $@\n";

  print scalar localtime() . " PERL WEBSERVER ONLINE\n";
  open(P,">/var/run/ev.pid");
  print P $$;
  close(P);

  my $pid;

  $SIG{INT} = $SIG{ALRM} = $SIG{HUP} = $SIG{KILL} = $SIG{USR2} = \&done;


  while (! $finished and my $client = $server->accept()) {
    if($client) {
      $SIG{INT} = $SIG{HUP} = $SIG{KILL} = sub {exit};
      my $done = 0;
      my @req = ();
      my $h11 = 0;
      my $cgi = 0;

      eval {
	do {
	  my $line  = <$client>;
	  $line =~ s/\r//g;
	  push @req,$line;
	  $h11++ if($line =~ /http\/1.1/i);
	  if ($h11) {
	    $done = 1 if($line eq "\n");
	  } else {
	    $done = 1;
	  }

	} while (! $done);
      };

      # mega crude but it's a demo waddya want?

      select $client;



      my($how,$url,$proto) = split(" ",$req[0]);
      my $docroot = "/etc/asterisk/perl/htdocs";
      my $urlroot = "$docroot$url";


      if(-d $urlroot) {
	foreach my $f (("index.cgi","index.cgi")) {
	  if(-f "$urlroot/$f") {
	    $urlroot .= "/$f";
	  }
	}
      }

      my ($FILE,$QUERY_STRING) = $urlroot =~ /([^\?]+)\?{0,1}(.*)/;
      if(! -f $FILE) {
	print genheads(200,"Content-Type: text/html");
	print "<B>NOT FOUND</B>";
	#exit;
	break;
      }

      if($FILE =~ /\.cgi/) {
	if($how =~ /get/i){
	  print genheads(200);
	  my $code = webserver_eval_file($FILE);
	  eval {
	    if($code) {
	      $code->({SOCKET => $client, SOCKET_NO => fileno($client),QUERY_STRING => $QUERY_STRING});
	    }
	    else {
	      print "Content-Type: text/html\n\n<h1>500 ERROR</h1>";
	    }
	  };
	  
	}
	else {
	  print genheads(200,"Content-Type: text/html");
	  print "<B>NOT SUPPORTED YET!!</B>";
	}
      }
      else {
	open(I,$FILE);
	print while(<I>);
	close I;
      }
      $client->close();
    }
  }

  }

1;
