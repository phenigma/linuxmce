package Asterisk::Embed;

sub {
  my $chan_name = shift;
  my $chan = asterisk_get_channel_by_name($chan_name);
  asterisk_log("LOG_NOTICE","This Demo Plays a file you can control with # and * and hangs up! $_[0]\n");
  asterisk_control_streamfile($chan,"demo-instruct","#","*","1","0",3000);
  asterisk_soft_hangup($chan);
}
