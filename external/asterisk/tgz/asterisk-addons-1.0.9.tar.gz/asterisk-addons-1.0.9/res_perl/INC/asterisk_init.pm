#use WebServer; # WebServer.pm makes a mini-web server
use Socket;
use POSIX;
use AstConfig;
use Data::Dumper;
use LoadFile;
use AstAPI;#<----- need this to talk to asterisk.
use PerlSwitch; # switching feature

# <configuration settings>
%PERL_CONFIG = (
		USE_CDR => 0,     # enable CDR
		USE_SWITCH => 0,  # enable switch
		USE_CONFIG => 0 # enable config
               );
# </configuration settings>



# LoadFile.pm implements the LoadFile func for app_perl to allow you 
# to put mini perl apps in 1 file and load them by name 
# each file is only loaded 1 time unless it changes on disk, then
# it will be re-read from disk and re-cached.
#
# exten => 1234,1,Perl(LoadFile:demo.pl:some arg)
#

sub startup() {
  asterisk_log("LOG_NOTICE","perl is in the house.");
  asterisk_log("LOG_NOTICE","Hi! I'm using perl to call ast_log\n\n");

  # uncomment the line below and the top line in this file to enable WebServer.pm
  # return("thread:web_server");
  return();
}

sub logtest() {
  asterisk_log("LOG_NOTICE",sprintf("TEST %s\n",join(" ",@_)));
}

sub shutdown() {
  asterisk_log("LOG_NOTICE","Perl sayin' C-YA!");
  return("");
}





# this function implements the perl config engine gateway
# basicly, you get the name of the config file as the arg
# and you need to init a AstConfig obj ($config) and return the 
# $config->return_data() func. this will config queues.conf
# as shown you could also connect to a DB here etc and build any 
# config you see fit.

sub perl_config() {
  my $arg = shift;
  my $config = init AstConfig();

  print "\n\n\nperl config called on $arg\n";

  if($arg eq "queues.conf") {

    $config->add_cat("somequeue");
    $config->add_var("somequeue","Member","Agent/1000,1234,1");
    $config->add_var("somequeue","Member","Agent/1001,1234,1");
    
    $config->add_cat("anotherqueue");
    $config->add_var("anotherqueue","Member","Agent/1000,1234,1");
    $config->add_var("anotherqueue","Member","Agent/1001,1234,1");
    
    return $config->return_data();
  }



}


# this is a demo of a typical func you call from extensions.conf
# arglist is a ':' seperated list of strings
# exten => 1234,1,Perl(perldemo:${EXTEN})
#
# this code is only compile once so you cant change it w/o restarting.
# when a func is called from extensions.conf, the 1st arg is always the channel name
# so typically you want to call
# my $chan_name = shift;
# my $chan = asterisk_get_channel_by_name($chan_name);
# $chan is the main argument to many of the asterisk_* functions

sub perldemo() {
  my $chan_name = shift;
  my $arg = shift;
  asterisk_log("LOG_NOTICE","EXTEN is [$arg]\n");
  my $chan = asterisk_get_channel_by_name($chan_name);

  asterisk_answer($chan);
  asterisk_streamfile($chan,"conf-onlyperson","1",0);
  asterisk_soft_hangup($chan);

# some code to try bringing up a channel / bridge a call
#  my $newchan = asterisk_request_and_dial("Zap","7",AST_FORMAT_ULAW,"Test",60000);
#  if($chan and $newchan) {
#    asterisk_bridge_call($chan,$newchan,0,0,1);
#  }
#  asterisk_soft_hangup($chan);
#  asterisk_hangup($newchan);
}


# some junk to document other possible api calls 
# docs someday!
#$data = asterisk_getdata($chan,"beep",5,5000);
#asterisk_log("LOG_NOTICE","input was $data!\n");
#asterisk_hangup($chan);
#asterisk_exec($chan,"Dial","Zap/g3/14149361212");
#asterisk_log("LOG_NOTICE",sprintf("digit was %d",asterisk_waitfordigit($chan,10000)));
#asterisk_moh_start($chan,"default");  



sub switch_exists() {
  my($type,$channel,$context,$exten,$priority,$callerid,$data) = @_;
  print "Perl Switch Exists: $context/$exten/$priority [$callerid] [$data]\n";
  return 0;
}

sub switch_canmatch() {
  my($type,$channel,$context,$exten,$priority,$callerid,$data) = @_;
  print "Perl Switch CanMatch: $context/$exten/$priority\n";
  return 0;
}

sub switch_exec() {
  my($type,$channel,$context,$exten,$priority,$callerid,$data) = @_;
  print "Perl Switch Exec: $context/$exten/$priority [$callerid] [$data]\n";
  return 0;
}

sub switch_matchmore() {
  my($type,$channel,$context,$exten,$priority,$callerid,$data) = @_;
  print "Switch MatchMore: $context/$exten/$priority\n";
  return 0;
}



my $switches = {
		exists => \&switch_exists,
		canmatch => \&switch_canmatch,
		exec => \&switch_exec,
		matchmore => \&switch_matchmore
	       };

perl_switch_register($switches) if($PERL_CONFIG{USE_SWITCH});

## cdr gateway function args are in order just like cdr_csv
## times are all expressed as ints
sub perl_cdr() {
  
}


1;
