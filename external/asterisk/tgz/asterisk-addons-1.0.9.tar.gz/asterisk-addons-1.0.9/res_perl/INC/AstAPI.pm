use AstAPIBase;
package LoadSym;
sub CloneSymbols($$) {
  my($hashRef,$newobj) = @_;
  
  my $code;
  my @export;
  my $export_code;

  my(%symbols);
  my(@symbols);
  %symbols = %{$hashRef};
  @symbols = sort(keys(%symbols));
  foreach (@symbols) {
    #printf("%-10.10s| %s\n", $_, $symbols{$_});
    my ($this) = $symbols{$_} =~ /::(.*)$/;
    $code .=  "*${newobj}::$this = $symbols{$_};\n";
  }

  return $code;
}


package AstAPI;

our %AST_CONTROL = (HANGUP 		=>	1,
		    RING 		=>	2,
		    RINGING 		=>	3,
		    ANSWER 		=>	4,
		    BUSY 		=>	5,
		    TAKEOFFHOOK 	=>	6,
		    OFFHOOK 		=>	7,
		    CONGESTION 		=>	8,
		    FLASH 		=>	9,
		    WINK 		=>	10,
		    OPTION 		=>	11,
		    RADIO_KEY 		=>	12,
		    RADIO_UNKEY 	=>	13,
		    PROGRESS 		=>	14
		   );


our %AST_FORMAT = (
		   G723_1    => (1 << 0),
		   GSM               => (1 << 1),
		   ULAW              => (1 << 2),
		   ALAW              => (1 << 3),
		   G726              => (1 << 4),
		   ADPCM     => (1 << 5),
		   SLINEAR   => (1 << 6),
		   LPC10     => (1 << 7),
		   G729A     => (1 << 8),
		   SPEEX     => (1 << 9),
		   ILBC              => (1 << 10),
		   MAX_AUDIO => (1 << 15),
		   JPEG              => (1 << 16),
		   PNG               => (1 << 17),
		   H261              => (1 << 18),
		   H263              => (1 << 19),
		   MAX_VIDEO => (1 << 24)
		  );


our %FORMAT_AST = reverse(%AST_FORMAT);

our %AST_STATE = (
		  DOWN   =>          0,
		  RESERVED => 1,
		  OFFHOOK  => 2,
		  DIALING  => 3,
		  RING        =>     4,
		  RINGING  => 5,
		  UP          =>     6,
		  BUSY     => 7,
		  DIALING_OFFHOOK => 8,
		  MUTE             => (1 << 16)
		 );

our %STATE_AST = reverse(%AST_STATE);

our $AST_DIGIT_ANY = "0123456789";

$code =
  LoadSym::CloneSymbols(\%AstAPIBasec::,"Asterisk::Embed") . 
  LoadSym::CloneSymbols(\%AstAPI::,"Asterisk::Embed");





eval $code;












1;
