package PerlSwitch;
$| = 1;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(perl_switch_handler perl_switch_register);
our @EXPORT_OK = (@EXPORT);
our $VERSION = 1;

my $switches = {
		exists => undef,
		canmatch => undef,
		exec => undef,
		matchmore => undef
	       };


sub perl_switch_register($) {
  my $new = shift;
  $switches->{exists} = $new->{exists} if($new->{exists});
  $switches->{canmatch} = $new->{canmatch} if($new->{canmatch});
  $switches->{exec} = $new->{exec} if($new->{exec});
  $switches->{matchmore} = $new->{matchmore} if($new->{matchmore});
}


sub perl_switch_handler() {
  my $type = $_[0];
  if(exists $switches->{$type}) {
    return $switches->{$type}->(@_);
  }

  return 0;
}


1;
