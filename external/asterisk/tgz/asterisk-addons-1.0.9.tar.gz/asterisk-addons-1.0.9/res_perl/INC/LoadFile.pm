# use me in asterisk_init.pm and call Perl(LoadFile:<file>:<arg1>:<..argn>)
package LoadFile;
$| = 1;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(LoadFile LoadFileCache LoadFileUnCache LoadFileCacheAll LoadFileUnCacheAll);
our @EXPORT_OK = (@EXPORT);
our $VERSION = 1;

my  %LOAD_FILE;
my $astdir = "/etc/asterisk/perl";

sub _mydie($) {
  my $msg = shift;
  Asterisk::Embed::asterisk_log("LOG_ERROR","$msg\n");
  return -1;
}

sub _inhale($) {
  my $file = shift;
  my ($filename) = $file =~ /\/([^\/]+)$/;

  $file and $filename or return 0;
  open(I,$file) or return 0;
  $/=undef;
  $code = <I>;
  close I;
  $/="\n";
  eval {
    my $ref = eval $code;
    return 0 if(! ref $ref);
    $LOAD_FILE{$filename} = [time,$ref];
    Asterisk::Embed::asterisk_log("LOG_NOTICE","LoadFile: Cached $filename\n");
  };
  if($@) {
    Asterisk::Embed::asterisk_log("LOG_ERROR","Perl Error: $@\n");
    return 0;
  }

  return 1;
}

sub LoadFileUnCache($) {
  my $filename = shift;
  if(exists $LOAD_FILE{$filename}) {
    delete $LOAD_FILE{$filename};
    Asterisk::Embed::asterisk_log("LOG_NOTICE","uncached $filename\n");
  }
  else {
    Asterisk::Embed::asterisk_log("LOG_NOTICE","$filename not cached\n");
  }
}


sub LoadFileCache($) {
  my $filename = shift;
  _inhale("$astdir/apps/$filename");
}

sub LoadFileCacheAll() {
  opendir(D,"$astdir/apps");

  my @files = readdir D;
  closedir D;
  foreach my $file (@files) {

    if($file =~ /.*\.pl$/) {
      LoadFileCache($file);
    }
  }
}


sub LoadFileUnCacheAll() {
  foreach my $file (keys %LOAD_FILE) {
      LoadFileUnCache($file);
  }
}

sub LoadFile() {
  my $chan_name = shift;
  my $filename = shift;
  my $path = "$astdir/apps/$filename";

  return _mydie("missing filename arguement.\n") unless($filename);
  my($mod,$code);
  my @st = stat "$path";
  return _mydie("missing file: $path!\n") unless(@st);

  if (exists $LOAD_FILE{$filename}) {
    ($mod,$code) = @{$LOAD_FILE{$filename}};
  }

  if (! $mod or $st[9] > $mod) { # new or newer
    if(! _inhale($path)) {
      return _mydie("Error Loading: $path!\n");
    }
    ($mod,$code) = @{$LOAD_FILE{$filename}};
  }

  return $code->($chan_name,@_);

}

1;
