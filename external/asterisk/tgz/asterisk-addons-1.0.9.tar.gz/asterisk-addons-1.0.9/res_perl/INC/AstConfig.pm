package AstConfig;
use strict;

sub _create_new_cat($) {
  my $name = shift;
  
  my $me = {
	    name => $name,
	    vars => [],
	   };

  return $me;
}

sub init(;) {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = [];
  bless ($self, $class);
  
}


sub return_data($) {
  my($self) = @_;
  return @{$self};
}

sub get_cat($$) {
  my($self,$cat_name) = @_;
  foreach(@{$self}) {
    if($_->{name} eq $cat_name) {
      return $_;
    }
  }
  return undef;

}

sub add_cat($$) {
  my $self = shift;
  my $cat_name = shift;
  my $cat = _create_new_cat($cat_name);
  push @{$self},$cat;
  return $cat;
}


sub add_var($$$$;$) {
  my($self,$cat_name,$var,$val,$pop) = @_;
  my $cat = $self->get_cat($cat_name);
  unless($cat) {
    $cat = $self->add_cat($cat_name);
  }
  pop @{$cat->{vars}} if($pop);
  push @{$cat->{vars}},{var => $var, val => $val};

}



1;
