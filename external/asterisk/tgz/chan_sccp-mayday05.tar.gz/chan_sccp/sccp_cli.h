#ifndef __SCCP_CLI_H
#define __SCCP_CLI_H

void sccp_register_cli(void);

#endif
