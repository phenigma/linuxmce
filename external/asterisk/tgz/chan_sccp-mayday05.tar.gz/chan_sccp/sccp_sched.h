int sccp_sched_delsession(void * data);
int sccp_sched_keepalive(void * data);


