void * socket_thread(void * ignore);

