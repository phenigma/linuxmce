#!/bin/bash

wget http://ftp.digium.com/pub/zaptel/zaptel-1.0.9.2.tar.gz
wget http://www.asterisk-support.de/mirror/libpri/libpri-1.0.9.tar.gz
wget http://www.asterisk-support.de/mirror/asterisk-1.09-STABLE/asterisk-1.0.9.tar.gz

gzip -d ./*.gz

tar -xf zaptel-1.0.9.2.tar
tar -xf libpri-1.0.9.tar
tar -xf asterisk-1.0.9.tar

cd zaptel-1.0.9.2
patch -p1 < ../patches/zaptel.patch
cd ..

cd libpri-1.0.9
patch -p1 < ../patches/libpri.patch
cd ..

cd asterisk-1.0.9
patch -p1 < ../patches/asterisk.patch
cd ..

echo "****************************************************"
echo "         Downloading and patching finished."
echo "****************************************************"
