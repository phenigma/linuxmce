#!/bin/bash

cd zaptel-1.0.9.2
make clean all
make install
cd ..

echo "****************************************************"
echo "ZAPTEL installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd libpri-1.0.9
make clean all
make install
cd ..

echo "****************************************************"
echo "LIBPRI installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read



cd qozap
make clean all
make install
cd ..

echo "****************************************************"
echo "quadBRI driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd cwain
make clean all
make install
cd ..

echo "****************************************************"
echo "cwain driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd zaphfc
make clean all
make install
cd ..

echo "****************************************************"
echo "hfc-pci driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd asterisk-1.0.9
make clean 
make all
make install

# to install sample asterisk configuration files uncomment the next line
#make samples
cd ..


echo "****************************************************"
echo " ASTERISK installed."
echo "             Installation finished."
echo "****************************************************"
