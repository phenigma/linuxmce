/*
 * qozap.c - Zaptel driver for the quadBRI PCI ISDN card
 * and the octoBRI PCI ISDN card!
 *
 * Copyright (C) 2003, 2004, 2005 Junghanns.NET GmbH
 *
 * Klaus-Peter Junghanns <kpj@junghanns.net>
 *
 * This program is free software and may be modified and
 * distributed under the terms of the GNU Public License.
 *
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <zaptel.h>
#include "qozap.h"

#if CONFIG_PCI

static int doubleclock=0;
static int ports=-1; /* autodetect */
static int debug=0;
static struct qoz_card *qoz_dev_list = NULL;
static int qoz_dev_count = 0;
static int totalBRIs = 0;
static struct pci_dev *multi_qoz = NULL;
static spinlock_t registerlock = SPIN_LOCK_UNLOCKED;

static int ztqoz_shutdown(struct zt_span *span);

int qoz_waitbusy(struct qoz_card *qoztmp) {
    int x=1000;
    while (x-- && (qoz_inb(qoztmp,qoz_R_STATUS) & 1));
    if (x < 0) {
	return -1;
    } else {
	return 0;
    }
}

void qoz_shutdownCard(struct qoz_card *qoztmp) {
    int s=0;
    unsigned long flags;
    int stports=0;
    if (qoztmp == NULL) {
	printk(KERN_INFO "qozap: shutting down NULL card!\n");
	return;
    }

    if (qoztmp->pci_io == NULL) {
	return;
    }

    if (debug)
	printk(KERN_INFO "qozap: shutting down card %d (cardID %d) at %p.\n",qoztmp->cardno,qoztmp->cardID,qoztmp->pci_io);

    if (qoztmp->ztdev != NULL) {
	stports = qoztmp->stports;
	for (s=0; s < stports; s++) {
	    if(qoztmp->ztdev->spans[s].flags & ZT_FLAG_RUNNING) {
		ztqoz_shutdown(&qoztmp->ztdev->spans[s]);
		if (debug)
		    printk(KERN_INFO "qozap: shutdown card %d span %d.\n",qoztmp->cardno,s+1);
	    }
	}
    }

    spin_lock_irqsave(&qoztmp->lock,flags);

    // turn off irqs
    qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 0); 
    qoz_outb(qoztmp,qoz_R_IRQMSK_MISC, 0); 
    qoz_outb(qoztmp,qoz_R_SCI_MSK, 0); 


    // softreset
    qoz_outb(qoztmp,qoz_R_CIRM,0x8);
    qoz_outb(qoztmp,qoz_R_CIRM,0x0); 
    qoz_waitbusy(qoztmp);

    qoz_outb(qoztmp,qoz_R_IRQMSK_MISC, 0); 
    qoz_outb(qoztmp,qoz_R_SCI_MSK, 0); 
    qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 0); 



    pci_write_config_word(qoztmp->pcidev, PCI_COMMAND, 0);	// disable memio

    if (qoztmp->pcidev != NULL) {
        pci_disable_device(qoztmp->pcidev);
//	qoztmp->pcidev = NULL;
    }
    
    spin_unlock_irqrestore(&qoztmp->lock,flags);

    if (qoztmp->ztdev != NULL) {
	stports = qoztmp->stports;
	for (s=0; s < stports; s++) {
	    if(qoztmp->ztdev->spans[s].flags & ZT_FLAG_REGISTERED) {
		zt_unregister(&qoztmp->ztdev->spans[s]);
		if (debug)
		    printk(KERN_INFO "qozap: unregistered card %d span %d.\n",qoztmp->cardno,s+1);
	    }
	}
	kfree(qoztmp->ztdev);
	qoztmp->ztdev = NULL;
    }

    iounmap((void *) qoztmp->pci_io);
    qoztmp->pci_io = NULL;

    free_irq(qoztmp->irq,qoztmp);
}

void qoz_doLEDs(struct qoz_card *qoztmp) {
    if ((qoztmp->type == 0xb520) && (qoztmp->stports == 4)){
//	if ((qoztmp->ticks > 0) && (qoztmp->ticks <= 300)) {
	    qoz_outb(qoztmp,qoz_R_GPIO_SEL,0x20 | 0x10);
    	    qoz_outb(qoztmp,qoz_R_GPIO_EN1,0xf);
	    qoz_outb(qoztmp,qoz_R_GPIO_OUT1,(qoztmp->leds[0] | (qoztmp->leds[1] << 1) | (qoztmp->leds[2] << 2) | (qoztmp->leds[3] << 3)));
/*	}
	if ((qoztmp->ticks > 300) && (qoztmp->ticks <= 600)) {
    	    qoz_outb(qoztmp,qoz_R_GPIO_EN1,0x0);
	} */
    }
}

void qoz_resetCard(struct qoz_card *qoztmp) {
    unsigned long flags;
    unsigned char i=0;
    spin_lock_irqsave(&(qoztmp->lock),flags);
    pci_write_config_word(qoztmp->pcidev, PCI_COMMAND, PCI_COMMAND_MEMORY);	// enable memio
    
    // soft reset
    qoz_outb(qoztmp,qoz_R_CIRM,0x8);
    qoz_outb(qoztmp,qoz_R_CIRM,0x0); 
    qoz_waitbusy(qoztmp);

    // fifo reset
    qoz_outb(qoztmp,qoz_R_CIRM,0x10);
    qoz_outb(qoztmp,qoz_R_CIRM,0x0); 
    qoz_waitbusy(qoztmp);

    // s/t reset
    qoz_outb(qoztmp,qoz_R_CIRM,0x40);
    qoz_outb(qoztmp,qoz_R_CIRM,0x0); 
    qoz_waitbusy(qoztmp);

    // set S0 amplitude
    qoz_outb(qoztmp,qoz_R_PWM_MD,0xa0);
    qoz_outb(qoztmp,qoz_R_PWM1,0x19);

    // set up the timer
    qoz_outb(qoztmp,qoz_R_TI_WD, 0x2); // 1 ms 
    qoz_outb(qoztmp,qoz_R_IRQMSK_MISC, 0x2); 
    qoz_outb(qoztmp,qoz_R_PCM_MD0, 0x1);

    // all state changes
    qoz_outb(qoztmp,qoz_R_SCI_MSK, 0xff); 

    if (qoztmp->type == 0xb552) {
        qoz_outb(qoztmp,qoz_R_FIFO_MD,0x16);
    } else {
        qoz_outb(qoztmp,qoz_R_FIFO_MD,0x26);
    }

    // double clock
    if (doubleclock == 1) {
	// hopefully you have set CLK_MODE correctly!
	qoz_outb(qoztmp,qoz_R_BRG_PCM_CFG,0x20); 
    } else {
	if (qoztmp->type == 0x08b4) {
	    qoz_outb(qoztmp,qoz_R_BRG_PCM_CFG,0x0); 
	} else {
	    qoz_outb(qoztmp,qoz_R_BRG_PCM_CFG,0x20); 
	}
    }
    qoz_outb(qoztmp,qoz_R_CTRL,0x0); 

    // LEDs RED
    qoztmp->leds[0] = 0x0;
    qoztmp->leds[1] = 0x0;
    qoztmp->leds[2] = 0x0;
    qoztmp->leds[3] = 0x0;
    qoztmp->leds[4] = 0x0;
    qoztmp->leds[5] = 0x0;
    qoztmp->leds[6] = 0x0;
    qoztmp->leds[7] = 0x0;

    /* Finally enable IRQ output */
    qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 0x8 | 0x1); 
    if (qoztmp->type == 0xb552) {
	qoztmp->stports = 8;
    } else {
	qoztmp->stports = 4;
    }
    qoztmp->ticks = 0;
    qoztmp->clicks = 0;

    for (i=0;i<qoztmp->stports;i++) {
	if (qoztmp->st[i].nt_mode) {
	    qoz_outb(qoztmp,qoz_R_ST_SYNC,0x8 | i);
	    break;
	}
    }
    if (i != qoztmp->stports) {
	qoz_outb(qoztmp,qoz_R_ST_SYNC,0x0);
    }
    spin_unlock_irqrestore(&(qoztmp->lock),flags);
}

void qoz_registerCard(struct qoz_card *qozcard) {
    spin_lock(&registerlock);
    if (qozcard != NULL) {
	qozcard->prev = NULL;
	qozcard->next = qoz_dev_list;
	if (qoz_dev_list) {
	    qoz_dev_list->prev = qozcard;
	}
	qoz_dev_list = qozcard;
	qozcard->cardno = ++qoz_dev_count;
    } else {
	printk(KERN_INFO "qozap: trying to register NULL card.\n");
    }
    spin_unlock(&registerlock);
}

static int qoz_dfifo_tx(struct qoz_card *qoztmp, int stport) {
    int chan = 2;
    int x=0;
    char fifo = 0;
    char offset = 0;

    if (qoztmp->type == 0xb552) {
	offset = 24;
    } else {
	offset = 28;
    }

    fifo = stport + offset;

    if (qoztmp->ztdev->chans[stport][chan].bytes2transmit < 1) {
	return 0;
    } else {
	/* select fifo */
	qoz_outb(qoztmp,qoz_R_FIFO,fifo << 1);    
	qoz_waitbusy(qoztmp);
    
	if (debug > 1)
	    printk(KERN_INFO "qozap: card %d stport %d TX [ ", qoztmp->cardno, stport + 1);
	/* copy frame to fifo */
    	for (x=0;x<qoztmp->ztdev->chans[stport][chan].bytes2transmit;x++) {
	    if (debug > 1)
	        printk("%#x ",qoztmp->dtxbuf[stport][x]);
    	    qoz_outb(qoztmp,qoz_A_FIFO_DATA0,qoztmp->dtxbuf[stport][x]);
	}
	if (debug > 1)
	    printk("] %d bytes\n",qoztmp->ztdev->chans[stport][chan].bytes2transmit);

	if (qoztmp->ztdev->chans[stport][chan].eoftx == 1) {
	    /* transmit HDLC frame */
    	    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x1);    
    	    qoz_waitbusy(qoztmp);
	}
    }
    return 0;
}

static int qoz_fifo_tx(struct qoz_card *qoztmp, char fifo) {
    int stport = fifo / 2;
    int chan = fifo % 2;

    /* select fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,0x80 | (fifo << 1));    
    qoz_waitbusy(qoztmp);
    /* transmit 8 bytes of transparent data */
    qoz_outdw(qoztmp,qoz_A_FIFO_DATA0,*((unsigned int *) &qoztmp->txbuf[stport][chan][0]));
    qoz_outdw(qoztmp,qoz_A_FIFO_DATA0,*((unsigned int *) &qoztmp->txbuf[stport][chan][4]));
	    
    return 0;
}

static int qoz_dfifo_rx(struct qoz_card *qoztmp, int stport) {
    unsigned char f1=1,f2=1,data,stat;
    unsigned char of1=0,of2=0;
    int len,i;
    unsigned short z1=1,z2=1;
    unsigned short oz1=0,oz2=0;
    char fifo = 0;
    char offset = 0;

    if (qoztmp->type == 0xb552) {
	offset = 24;
    } else {
	offset = 28;
    }

    fifo = stport + offset;
    // select rx fifo
    
    qoz_outb(qoztmp,qoz_R_FIFO,(fifo << 1) | 1);    
    qoz_waitbusy(qoztmp);

    while ((of1 != f1) && (of2 != f2)) {
        of1 = f1;
        of2 = f2;
        f1 = qoz_inb(qoztmp,qoz_A_F1) & 0xf;
        f2 = qoz_inb(qoztmp,qoz_A_F2) & 0xf;
    }
    
    if (f1 == f2) {
	/* no frame */
	qoztmp->st[stport].drx--;
	qoztmp->ztdev->chans[stport][2].bytes2receive = 0;
	return 0;
    }
    
    while ((oz1 != z1) && (oz2 != z2)) {
        oz1 = z1;
        oz2 = z2;
	if (qoztmp->type != 0xb552) {
    	    z1 = qoz_inw(qoztmp,qoz_A_Z1) & 0x7ff;
	    z2 = qoz_inw(qoztmp,qoz_A_Z2) & 0x7ff;
	} else {
    	    z1 = qoz_inw(qoztmp,qoz_A_Z1) & 0x3ff;
	    z2 = qoz_inw(qoztmp,qoz_A_Z2) & 0x3ff;
	}
    }
    
    if (qoztmp->type == 0xb552) {
	len = z1 - z2;
	if (len < 0) {
	    len += qoz_DFIFO_SIZE8;
	}
    } else {
	len = z1 - z2;
	if (len < 0) {
	    len += qoz_DFIFO_SIZE4;
	}
    }

    if (len > qoz_DFIFO_SIZE4) {
	printk(KERN_INFO "\nqozap: buffer overflow in D channel RX!\n");
	qoztmp->ztdev->chans[stport][2].bytes2receive = 0;
	qoztmp->ztdev->chans[stport][2].eofrx = 0;
    } else {
	if (debug > 1) printk(KERN_INFO "qozap: card %d span %d RX [ ", qoztmp->cardno, stport + 1);
	for (i=0; i<len; i++) {
    	    data = qoz_inb(qoztmp,qoz_A_FIFO_DATA0);
	    qoztmp->drxbuf[stport][i] = data;
	    if (debug > 1) printk("%#x ",data);
	}
	if (debug > 1) printk("] %d bytes\n", len);
	qoztmp->ztdev->chans[stport][2].bytes2receive = i;
	qoztmp->ztdev->chans[stport][2].eofrx = 1;
    }

    stat = qoz_inb(qoztmp,qoz_A_FIFO_DATA0);
    if (stat != 0x0) {
	// bad CRC, skip it
	printk(KERN_INFO "qozap: CRC error for HDLC frame on card %d (cardID %d) S/T port %d\n",qoztmp->cardno, qoztmp->cardID, stport+1);
	qoztmp->ztdev->chans[stport][2].bytes2receive = 0;
	qoztmp->ztdev->chans[stport][2].eofrx = 0;
//        zt_qevent_nolock(&qoztmp->ztdev->chans[stport][2], ZT_EVENT_BADFCS);
    }
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x1);    
    qoz_waitbusy(qoztmp);

    /* frame recevived */
    if (qoztmp->st[stport].drx > 0) { 
	qoztmp->st[stport].drx--;
    } else {
	printk(KERN_INFO "qozap: trying to receive too much (card %d span %d drx %d)\n", qoztmp->cardno, stport+1, qoztmp->st[stport].drx);
	qoztmp->st[stport].drx = 0;
    }
    return 0;
}


static int qoz_fifo_rx(struct qoz_card *qoztmp, char fifo) {
    int stport = fifo / 2;
    int chan = fifo % 2;
    unsigned char data;
    int len,i;
    unsigned short z1=1,z2=1;
    unsigned short oz1=0,oz2=0;
    int mumbojumbo=0;

        /* select rx fifo */
	qoz_outb(qoztmp,qoz_R_FIFO,0x80 | (fifo << 1) | 1);    
        qoz_waitbusy(qoztmp);
    
	while ((oz1 != z1) && (oz2 != z2)) {
	    oz1 = z1;
	    oz2 = z2;
	    z1 = qoz_inw(qoztmp,qoz_A_Z1) & 0x7f;
    	    z2 = qoz_inw(qoztmp,qoz_A_Z2) & 0x7f;
	}
	len = z1 - z2;
	if (len < 0) {
	    len += qoz_FIFO_SIZE;
	}
	if (len > 2 * ZT_CHUNKSIZE) {
	    mumbojumbo = len - (2 * ZT_CHUNKSIZE);
	    len = ZT_CHUNKSIZE;
	    for (i=0;i<mumbojumbo;i++) {
    		data = qoz_inb(qoztmp,qoz_A_FIFO_DATA0);
	    }
	    qoztmp->clicks++;
	    if ((qoztmp->clicks > 100) || (debug == 4)) {
		printk(KERN_CRIT "qozap: dropped audio card %d cardid %d bytes %d z1 %d z2 %d\n", qoztmp->cardno, qoztmp->cardID, mumbojumbo, z1, z2);
		qoztmp->clicks = 0;
	    }
	}
	if (len < ZT_CHUNKSIZE) {
//	    printk(KERN_INFO "qozap: not enough to receive (%d bytes)\n",len);
	    return 0;
	} else {
	    *((unsigned int *) &qoztmp->rxbuf[stport][chan][0]) = qoz_indw(qoztmp,qoz_A_FIFO_DATA0);
	    *((unsigned int *) &qoztmp->rxbuf[stport][chan][4]) = qoz_indw(qoztmp,qoz_A_FIFO_DATA0);
	}

	zt_ec_chunk(&qoztmp->ztdev->spans[stport].chans[chan], qoztmp->ztdev->spans[stport].chans[chan].readchunk, qoztmp->ztdev->spans[stport].chans[chan].writechunk);

//    printk(KERN_INFO "s/t port %d, channel %d, dbufi=%d, f1=%d, f2=%d, z1=%d, z2=%d  => len = %d stat=%#x, hdlc=%d\n",stport,chan,qoztmp->st[stport].dbufi,f1,f2,z1,z2,len,stat,hdlc);    
    return 0;
}


static inline void qoz_run(struct qoz_card *qoztmp) {
    int s=0;
    if (qoztmp->ztdev != NULL) {
	for (s=0;s<qoztmp->stports;s++) {
	    if (qoztmp->ztdev->spans[s].flags & ZT_FLAG_RUNNING) {
		/* oh zaptel! tell us what to transmit... */
    		zt_transmit(&qoztmp->ztdev->spans[s]);
	        /* B1 xmit */
		qoz_fifo_tx(qoztmp, s * 2);
		/* B2 xmit */
		qoz_fifo_tx(qoztmp, (s * 2) + 1);
		/* D xmit */
		qoz_dfifo_tx(qoztmp, s);

		qoztmp->ztdev->chans[s][2].bytes2receive = 0;
		qoztmp->ztdev->chans[s][2].bytes2transmit = 0;
		qoztmp->ztdev->chans[s][2].eofrx = 0;
		qoztmp->ztdev->chans[s][2].eoftx = 0;

	    }
	    /* B1 receive */
	    qoz_fifo_rx(qoztmp,(s*2));
	    /* B2 receive */
	    qoz_fifo_rx(qoztmp,(s*2)+1);
	    /* d-chan data */
	    if (qoztmp->st[s].drx > 0) {
	        if (debug > 2)
		    printk(KERN_CRIT "qozap: card %d st[%d].drx = %d\n", qoztmp->cardno, s, qoztmp->st[s].drx);
		qoz_dfifo_rx(qoztmp, s);
	    }
	    if (qoztmp->ztdev->spans[s].flags & ZT_FLAG_RUNNING) {
	        /* oh zaptel! thou shall receive! */
		zt_receive(&(qoztmp->ztdev->spans[s]));
	    }
	} 
    }
}

#ifdef LINUX26
static irqreturn_t qoz_interrupt(int irq, void *dev_id, struct pt_regs *regs) {
#else
static void qoz_interrupt(int irq, void *dev_id, struct pt_regs *regs) {
#endif
    struct qoz_card *qoztmp = dev_id;
    struct zt_qoz *ztqoz = qoztmp->ztdev;
    unsigned long flags;
    unsigned char irq_misc,irq_sci,status,l1state,irq_foview,fi;
    int st=0,i=0,offset=0;

    if (!qoztmp || qoztmp->dead) {
#ifdef LINUX26
		return IRQ_NONE;
#else
		return;
#endif		
    }

    if (!qoztmp->pci_io) {
	    printk(KERN_CRIT "qozap: no pci mem\n");
#ifdef LINUX26
		return IRQ_NONE;
#else
		return;
#endif		
    }
    
    spin_lock_irqsave(&(qoztmp->lock),flags);
    status = qoz_inb(qoztmp,qoz_R_STATUS);
    irq_sci = qoz_inb(qoztmp,qoz_R_SCI);

    if (!(status & 0x80) && !(status & 0x40) && (irq_sci == 0)) {
//	printk(KERN_CRIT "qozap: status %#x\n", status);
	// it's not us!
	spin_unlock_irqrestore(&(qoztmp->lock),flags);
#ifdef LINUX26
		return IRQ_NONE;
#else
		return;
#endif		
    }

    // misc irq
    if (status & 0x40) {
	irq_misc = qoz_inb(qoztmp,qoz_R_IRQ_MISC);
	if (irq_misc & 0x2)  {
	    // qozap timer
	    qoztmp->ticks++;
	    qoz_run(qoztmp);
	    if (qoztmp->ticks % 100) {
		qoz_doLEDs(qoztmp);
	    }
	    if (qoztmp->ticks > 600) {
		qoztmp->ticks = 0;
	    }
	}
	if (irq_misc & 0x4) {
	//    printk(KERN_INFO "qozap proc/nonproc irq\n");
	}
    }
    if (status & 0x80) {
	/* fifo irq */
	irq_foview = qoz_inb(qoztmp,qoz_R_IRQ_OVIEW);
        if (qoztmp->type == 0xb552) {
	    if (irq_foview & 0x60) {
		offset = 0;
		fi = qoz_inb(qoztmp,qoz_R_IRQ_FIFO_BL6);
		for (i=0; i < 8; i++) {
		    if (fi & (1 << i)) {
			st = offset + (i / 2);
			if (i % 2) {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC RX irq fifo %d span %d\n", i, st+1);
				qoztmp->st[st].drx += 1;			
			} else {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC TX irq fifo %d span %d\n", i, st+1);
			}
		    }
		}
	    }
	    if (irq_foview & 0x80) {
		offset = 4;
		fi = qoz_inb(qoztmp,qoz_R_IRQ_FIFO_BL7);
		for (i=0; i < 8; i++) {
		    if (fi & (1 << i)) {
			st = offset + (i / 2);
			if (i % 2) {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC RX irq fifo %d span %d\n", i, st+1);
				qoztmp->st[st].drx += 1;			
			} else {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC TX irq fifo %d span %d\n", i, st+1);
			}
		    }
		}
	    }
	} else {
	    if (irq_foview & 0x80) {
		fi = qoz_inb(qoztmp,qoz_R_IRQ_FIFO_BL7);
		for (i=0; i < 8; i++) {
		    if (fi & (1 << i)) {
			st = i / 2;
			if (i % 2) {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC RX irq fifo %d span %d\n", i, st+1);
				qoztmp->st[st].drx += 1;			
			} else {
			    if (debug > 2) 
		    		printk(KERN_CRIT "qozap: HDLC TX irq fifo %d span %d\n", i, st+1);
			}
		    }
		}
	    }
	}
    }
    
    /* state machine irq */
    if (irq_sci != 0) {
	if (debug > 1) {
	    printk(KERN_INFO "R_BERT_STA = %#x\n", qoz_inb(qoztmp, qoz_R_BERT_STA) & 7);
	}
	for (st=0;st<qoztmp->stports;st++) {
	    if (irq_sci & (1 << st)) {
		qoz_outb(qoztmp,qoz_R_ST_SEL,st);
		l1state = qoz_inb(qoztmp,qoz_A_ST_RD_STA) & 0xf;
		if (debug > 1) {
		    printk(KERN_INFO "A_ST_RD_STA = %#x\n", qoz_inb(qoztmp, qoz_A_ST_RD_STA));
		}
		if (qoztmp->st[st].nt_mode == 1) {
		    if (debug)
			printk(KERN_INFO "card %d span %d state G%d (A_ST_RD_STA = %#x)\n",qoztmp->cardno,st+1,l1state,qoz_inb(qoztmp,qoz_A_ST_RD_STA));
		    // NT state machine
		    if (l1state == 3) {
			// keep layer1 up!
			if (qoztmp->stports == 8) {
			    sprintf(ztqoz->spans[st].desc,"octoBRI PCI ISDN Card %d Span %d [NT] Layer 1 ACTIVATED (G%d)",qoztmp->cardno ,st + 1, l1state);
			} else {
			    sprintf(ztqoz->spans[st].desc,"quadBRI PCI ISDN Card %d Span %d [NT] (cardID %d) Layer 1 ACTIVATED (G%d)",qoztmp->cardno ,st + 1,ztqoz->card->cardID, l1state);
			}
			qoz_outb(qoztmp,qoz_A_ST_WR_STA,3 | 0x10 );
			qoztmp->leds[st] = 1;
		    } else {
			if (qoztmp->stports == 8) {
			    sprintf(ztqoz->spans[st].desc,"octoBRI PCI ISDN Card %d Span %d [NT] Layer 1 DEACTIVATED (G%d)",qoztmp->cardno ,st + 1, l1state);
			} else {
			    sprintf(ztqoz->spans[st].desc,"quadBRI PCI ISDN Card %d Span %d [NT] (cardID %d) Layer 1 DEACTIVATED (G%d)",qoztmp->cardno ,st + 1,ztqoz->card->cardID, l1state);
			}
			qoztmp->leds[st] = 0;
		    }
		} else {
		    if (debug)
			printk(KERN_INFO "card %d span %d state F%d (A_ST_RD_STA = %#x)\n",qoztmp->cardno,st+1,l1state,qoz_inb(qoztmp,qoz_A_ST_RD_STA));
		    // TE state machine
		    if (l1state == 3) {
			/* keep layer1 up, if the span is started. */
			if (qoztmp->ztdev->spans[st].flags & ZT_FLAG_RUNNING) {
    			    qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x60);
			}
			qoztmp->leds[st] = 0;
			if (qoztmp->stports == 8) {
			    sprintf(ztqoz->spans[st].desc,"octoBRI PCI ISDN Card %d Span %d [TE] Layer 1 DEACTIVATED (F%d)",qoztmp->cardno ,st + 1, l1state);
			} else {
			    sprintf(ztqoz->spans[st].desc,"quadBRI PCI ISDN Card %d Span %d [TE] (cardID %d) Layer 1 DEACTIVATED (F%d)",qoztmp->cardno ,st + 1,ztqoz->card->cardID, l1state);
			}
		    } else if (l1state == 7) {
			qoztmp->leds[st] = 1;
			if (qoztmp->stports == 8) {
			    sprintf(ztqoz->spans[st].desc,"octoBRI PCI ISDN Card %d Span %d [TE] Layer 1 ACTIVATED (F%d)",qoztmp->cardno ,st + 1, l1state);
			} else {
			    sprintf(ztqoz->spans[st].desc,"quadBRI PCI ISDN Card %d Span %d [TE] (cardID %d) Layer 1 ACTIVATED (F%d)",qoztmp->cardno ,st + 1,ztqoz->card->cardID, l1state);
			}
		    } else {
			if (qoztmp->stports == 8) {
			    sprintf(ztqoz->spans[st].desc,"octoBRI PCI ISDN Card %d Span %d [TE] Layer 1 DEACTIVATED (F%d)",qoztmp->cardno ,st + 1, l1state);
			} else {
			    sprintf(ztqoz->spans[st].desc,"quadBRI PCI ISDN Card %d Span %d [TE] (cardID %d) Layer 1 DEACTIVATED (F%d)",qoztmp->cardno ,st + 1,ztqoz->card->cardID, l1state);
			}    
		    }
		}
		
	    }
	}
    }
    spin_unlock_irqrestore(&(qoztmp->lock),flags);
#ifdef LINUX26
	return IRQ_RETVAL(1);
#endif		
}

static int ztqoz_open(struct zt_chan *chan) {
//    printk(KERN_INFO "qozap: channel %d opened.\n",chan->channo);
#ifndef LINUX26
    MOD_INC_USE_COUNT;
#else
    try_module_get(THIS_MODULE);
#endif
    return 0;
}

static int ztqoz_close(struct zt_chan *chan) {
//    printk(KERN_INFO "qozap: channel %d closed.\n",chan->channo);
#ifndef LINUX26
    MOD_DEC_USE_COUNT;
#else
    module_put(THIS_MODULE);
#endif
    return 0;
}

static int ztqoz_rbsbits(struct zt_chan *chan, int bits) {
    return 0;
}

static int ztqoz_ioctl(struct zt_chan *chan, unsigned int cmd, unsigned long data) {
        switch(cmd) {
        default:
                return -ENOTTY;
        }
        return 0;
}

static int ztqoz_startup(struct zt_span *span) {
    struct zt_qoz *qozt = span->pvt;
    struct qoz_card *qoztmp = qozt->card;
    unsigned long flags;
    int alreadyrunning;
    int i=0;
    int offset = 0;
    
    if (qoztmp == NULL) {
	printk(KERN_INFO "qozap: no card for span at startup!\n");
    }
    
    alreadyrunning = span->flags & ZT_FLAG_RUNNING;
//    printk(KERN_CRIT "already running %d flags %d\n", alreadyrunning, span->flags);

    if (!alreadyrunning) {
	span->chans[2].flags &= ~ZT_FLAG_HDLC;
	span->chans[2].flags |= ZT_FLAG_BRIDCHAN;
    
	/* setup B channel buffers (8 bytes each) */
	for (i=0; i<2 ; i++) {
	    memset(qoztmp->rxbuf[span->offset][i],0x0,sizeof(qoztmp->rxbuf[span->offset][i]));
    	    span->chans[i].readchunk = qoztmp->rxbuf[span->offset][i];
    	    memset(qoztmp->txbuf[span->offset][i],0x0,sizeof(qoztmp->txbuf[span->offset][i]));
	    span->chans[i].writechunk = qoztmp->txbuf[span->offset][i];
	}
	/* setup D channel buffer */
    	memset(qoztmp->dtxbuf[span->offset],0x0,sizeof(qoztmp->dtxbuf[span->offset]));
	span->chans[2].writechunk = qoztmp->dtxbuf[span->offset];
	qoztmp->ztdev->chans[span->offset][2].maxbytes2transmit = sizeof(qoztmp->dtxbuf[span->offset]);

	memset(qoztmp->drxbuf[span->offset],0x0,sizeof(qoztmp->drxbuf[span->offset]));
    	span->chans[2].readchunk = qoztmp->drxbuf[span->offset];

	span->flags |= ZT_FLAG_RUNNING;
    } else {
//	printk(KERN_CRIT "already running\n");
	return 0;
    }

    spin_lock_irqsave(&qoztmp->lock,flags);
    // irqs off
    qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 0); 

    if (qoztmp->type == 0xb552) {
	offset = 24;
    } else {
	offset = 28;
    }

    /* setup D-FIFO TX */
    qoz_outb(qoztmp,qoz_R_FIFO,(span->offset + offset) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0xD);
    qoz_outb(qoztmp,qoz_A_SUBCH_CFG,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,((span->offset * 4) + 2) << 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    /* setup D-FIFO RX */
    qoz_outb(qoztmp,qoz_R_FIFO,((span->offset + offset) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0xD);
    qoz_outb(qoztmp,qoz_A_SUBCH_CFG,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,(((span->offset * 4) + 2) << 1) | 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    /* setup B1-FIFO TX */
    qoz_outb(qoztmp,qoz_R_FIFO,(span->offset * 2) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,(span->offset * 4) << 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    /* setup B1-FIFO RX */
    qoz_outb(qoztmp,qoz_R_FIFO,((span->offset * 2) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,((span->offset * 4) << 1) | 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    /* setup B2-FIFO TX */
    qoz_outb(qoztmp,qoz_R_FIFO,((span->offset * 2) + 1) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,((span->offset * 4) + 1) << 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    /* setup B2-FIFO RX */
    qoz_outb(qoztmp,qoz_R_FIFO,(((span->offset * 2) + 1) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_R_INC_RES_FIFO,0x2);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_CHANNEL,((((span->offset) * 4) + 1) << 1) | 1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x1);

    if (debug)
        printk(KERN_INFO "qozap: starting card %d span %d/%d.\n",qoztmp->cardno,span->spanno,span->offset);
    
    /* activate layer 1 */
    qoz_outb(qoztmp,qoz_R_ST_SEL,span->offset);
    if (qoztmp->st[span->offset].nt_mode == 1) {
	// NT mode
	qoz_outb(qoztmp,qoz_A_ST_CTRL0,0x7);
	qoz_outb(qoztmp,qoz_A_ST_CTRL1,0x0);
	qoz_outb(qoztmp,qoz_A_ST_CTRL2,0x3);
	qoz_outb(qoztmp,qoz_A_ST_CLK_DLY,0x60 | CLKDEL_NT);
    } else {
	// TE mode
	qoz_outb(qoztmp,qoz_A_ST_CTRL0,0x3);
	qoz_outb(qoztmp,qoz_A_ST_CTRL1,0x0);
	qoz_outb(qoztmp,qoz_A_ST_CTRL2,0x3);
	qoz_outb(qoztmp,qoz_A_ST_CLK_DLY,CLKDEL_TE);
    }

    qoz_outb(qoztmp,qoz_R_ST_SEL,span->offset);
    if (qoztmp->st[span->offset].nt_mode == 1) {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x80); 
    } else {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x0); 
    }
    /* enable irqs */
    qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 8 | 1); 

    qoz_outb(qoztmp,qoz_R_ST_SEL,span->offset);
    if (qoztmp->st[span->offset].nt_mode == 1) {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x60 | 0x80); // ACT, G2->G3 EN
    } else {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x60); // start Activation
    }
    spin_unlock_irqrestore(&qoztmp->lock,flags);

    return 0;
}

static int ztqoz_shutdown(struct zt_span *span) {
    struct zt_qoz *ztqoz = span->pvt;
    struct qoz_card *qoztmp = ztqoz->card;
    unsigned long flags;
    int alreadyrunning;
    int offset = 0;
    
    if (qoztmp == NULL) {
	printk(KERN_CRIT "qozap: qoztmp == NULL!\n");
	return 0;
	
    }

    alreadyrunning = span->flags & ZT_FLAG_RUNNING;
    
    if (!alreadyrunning) {
	return 0;
    }

//    printk(KERN_CRIT "qozap: stopping card %d port %d.\n",qoztmp->cardno, span->offset + 1);

    // turn off irqs for all fifos
    if (qoztmp->type == 0xb552) {
	offset = 24;
    } else {
	offset = 28;
    }
    spin_lock_irqsave(&qoztmp->lock,flags);

    /* disable D TX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,(span->offset + offset) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0);

    /* disable D RX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,((span->offset + offset) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x1);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0);

    /* disable B1 TX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,(span->offset * 2) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0);

    /* disable B1 RX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,((span->offset * 2) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0);

    /* disable B2 TX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,(((span->offset) * 2) + 1) << 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0);

    /* disable B2 RX fifo */
    qoz_outb(qoztmp,qoz_R_FIFO,((((span->offset) * 2) + 1) << 1) | 1);
    qoz_waitbusy(qoztmp);
    qoz_outb(qoztmp,qoz_A_CON_HDLC,0x2);
    qoz_outb(qoztmp,qoz_A_IRQ_MSK,0x0); 

    span->flags &= ~ZT_FLAG_RUNNING;

    /* Deactivate Layer 1 */
    qoz_outb(qoztmp,qoz_R_ST_SEL,span->offset);
    if (qoztmp->st[span->offset].nt_mode == 1) {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x40); 
    } else {
	qoz_outb(qoztmp,qoz_A_ST_WR_STA,0x40);
    }
    spin_unlock_irqrestore(&qoztmp->lock,flags);


//    printk(KERN_CRIT "qozap: card %d span %d/%d down.\n",qoztmp->cardno,span->spanno,span->offset);
    return 0;
}

static int ztqoz_maint(struct zt_span *span, int cmd) {
    return 0;
}

static int ztqoz_chanconfig(struct zt_chan *chan,int sigtype) {
//    printk(KERN_INFO "chan_config sigtype=%d\n",sigtype);
    return 0;
}

static int ztqoz_spanconfig(struct zt_span *span,struct zt_lineconfig *lc) {
//    span->lineconfig = lc->lineconfig;
    return 0;
}

static int ztqoz_initialize(struct zt_qoz *ztqoz) {
    struct qoz_card *qoztmp = ztqoz->card;
    int i=0,s=0;
    
    for (s=0; s < ztqoz->card->stports; s++) {
	memset(&ztqoz->spans[s],0,sizeof(struct zt_span)); // you never can tell...
	sprintf(ztqoz->spans[s].name,"ztqoz/%d/%d",qoz_dev_count + 1,s + 1);
	if (ztqoz->card->stports == 8) {
	    if (qoztmp->st[s].nt_mode == 1){
		sprintf(ztqoz->spans[s].desc,"octoBRI PCI ISDN Card %d Span %d [NT]",qoztmp->cardno,s + 1);
	    } else {
		sprintf(ztqoz->spans[s].desc,"octoBRI PCI ISDN Card %d Span %d [TE]",qoztmp->cardno,s + 1);
	    }
	} else {
	    if (ztqoz->card->cardID < 0xff) {
		if (qoztmp->st[s].nt_mode == 1){
		    sprintf(ztqoz->spans[s].desc,"quadBRI PCI ISDN Card %d Span %d [NT] (cardID %d)",qoztmp->cardno,s + 1,ztqoz->card->cardID);
		} else {
		    sprintf(ztqoz->spans[s].desc,"quadBRI PCI ISDN Card %d Span %d [TE] (cardID %d)",qoztmp->cardno,s + 1,ztqoz->card->cardID);
		}
	    } else {
		if (qoztmp->st[s].nt_mode == 1){
		    sprintf(ztqoz->spans[s].desc,"quadBRI PCI ISDN Card %d Span %d [NT]",qoztmp->cardno,s + 1);
		} else {
		    sprintf(ztqoz->spans[s].desc,"quadBRI PCI ISDN Card %d Span %d [TE]",qoztmp->cardno,s + 1);
		}
	    }
	}

        ztqoz->spans[s].spanconfig = ztqoz_spanconfig;
        ztqoz->spans[s].chanconfig = ztqoz_chanconfig;
        ztqoz->spans[s].startup = ztqoz_startup;
        ztqoz->spans[s].shutdown = ztqoz_shutdown;
        ztqoz->spans[s].maint = ztqoz_maint;
        ztqoz->spans[s].rbsbits = ztqoz_rbsbits;
        ztqoz->spans[s].open = ztqoz_open;
        ztqoz->spans[s].close = ztqoz_close;
        ztqoz->spans[s].ioctl = ztqoz_ioctl;

        ztqoz->spans[s].chans = ztqoz->chans[s];
        ztqoz->spans[s].channels = 3;
        ztqoz->spans[s].deflaw = ZT_LAW_ALAW;
        ztqoz->spans[s].linecompat = ZT_CONFIG_AMI | ZT_CONFIG_CCS; // <--- this is really BS
        init_waitqueue_head(&ztqoz->spans[s].maintq);
        ztqoz->spans[s].pvt = ztqoz;
        ztqoz->spans[s].offset = s;

	for (i=0; i < ztqoz->spans[s].channels; i++) {
	    memset(&(ztqoz->chans[s][i]),0x0,sizeof(struct zt_chan));
	    sprintf(ztqoz->chans[s][i].name,"ztqoz%d/%d/%d",qoz_dev_count + 1,s + 1,i + 1);
	    ztqoz->chans[s][i].pvt = ztqoz;
	    ztqoz->chans[s][i].sigcap =  ZT_SIG_EM | ZT_SIG_CLEAR | ZT_SIG_FXSLS | ZT_SIG_FXSGS | ZT_SIG_FXSKS | ZT_SIG_FXOLS | ZT_SIG_FXOGS | ZT_SIG_FXOKS | ZT_SIG_CAS | ZT_SIG_SF;
	    ztqoz->chans[s][i].chanpos = i + 1; 
	}

	if (zt_register(&ztqoz->spans[s],0)) {
	    printk(KERN_INFO "qozap: unable to register zaptel span %d!\n",s+1);
	    return -1;
	}
//	 printk(KERN_INFO "qozap: registered zaptel span %d.\n",s+1);
    }

    return 0;
}

int qoz_findCards(unsigned int pcidid) {
    struct pci_dev *tmp;
    struct qoz_card *qoztmp = NULL;
    struct zt_qoz *ztqoz = NULL;
    int i=0;
    unsigned char dips=0;
    int cid=0;
    int modes=0;
    tmp = pci_find_device(PCI_VENDOR_ID_CCD,pcidid,multi_qoz);
    while (tmp != NULL) {
	multi_qoz = tmp;	// skip this next time.

	if (pci_enable_device(tmp)) {
	    multi_qoz = NULL;
	    return -1;
	}

	qoztmp = kmalloc(sizeof(struct qoz_card),GFP_KERNEL);
	if (!qoztmp) {
	    printk(KERN_WARNING "qozap: unable to kmalloc!\n");
	    pci_disable_device(tmp);
	    multi_qoz = NULL;
	    return -ENOMEM;
	}
	memset(qoztmp, 0x0, sizeof(struct qoz_card));
	
	spin_lock_init(&qoztmp->lock);
	qoztmp->pcidev = tmp;
	qoztmp->pcibus = tmp->bus->number;
	qoztmp->pcidevfn = tmp->devfn; 

	if (!tmp->irq) {
	    printk(KERN_WARNING "qozap: no irq!\n");
	} else {
	    qoztmp->irq = tmp->irq;
	}

	qoztmp->pci_io = (char *) tmp->resource[1].start;
	if (!qoztmp->pci_io) {
	    printk(KERN_WARNING "qozap: no iomem!\n");
	    pci_disable_device(tmp);
	    multi_qoz = NULL;
	    return -EIO;
	}
	
	if (request_irq(qoztmp->irq, qoz_interrupt, SA_INTERRUPT | SA_SHIRQ, "qozap", qoztmp)) {
	    printk(KERN_WARNING "qozap: unable to register irq\n");
	    kfree(qoztmp);
	    pci_disable_device(tmp);
	    multi_qoz = NULL;
	    return -EIO;
	}
	
	
	qoztmp->pci_io = ioremap((ulong) qoztmp->pci_io, 256);
	
		       
	pci_write_config_word(qoztmp->pcidev, PCI_COMMAND, PCI_COMMAND_MEMORY);	// enable memio

	// disable ints
	qoz_outb(qoztmp,qoz_R_IRQ_CTRL, 0); 

	ztqoz = kmalloc(sizeof(struct zt_qoz),GFP_KERNEL);
	if (!ztqoz) {
	    printk(KERN_INFO "qozap: unable to kmalloc!\n");
	    qoz_shutdownCard(qoztmp);
	    kfree(qoztmp);
	    multi_qoz = NULL;
	    return -ENOMEM;
	}
	memset(ztqoz, 0x0, sizeof(struct zt_qoz));

	if (pcidid == PCI_DEVICE_ID_CCD_M) {
	    qoztmp->stports = 8;
	} else {
	    qoztmp->stports = 4;
	}
	

        if ((tmp->subsystem_device==0xb520) && (pcidid == PCI_DEVICE_ID_CCD_M4)) {
	//    printk(KERN_INFO "MODES = %#x.\n",modes);
	    qoz_outb(qoztmp,qoz_R_GPIO_SEL,0x80 | 0x40);
	    dips = (qoz_inb(qoztmp,qoz_R_GPIO_IN1) >> 5);
	    cid = 7;
	    for (i=0;i<3;i++) {
	        if ((dips & (1 << i)) != 0) {
	    	cid -= (1 << (2-i));
	        }
	    }
	//	printk(KERN_INFO "DIPS = %#x CID= %#x\n",dips,cid);
        } else {
	    cid = 0xff;
        }

	if (ports == -1) {
    	    if ((tmp->subsystem_device==0xb520) && (pcidid == PCI_DEVICE_ID_CCD_M4)) {
		modes = qoz_inb(qoztmp,qoz_R_GPI_IN3) >> 4;
	    } else {
		modes = 0; // assume TE mode
	    }
	} else {
	    modes = ports >> totalBRIs;
	}

	if (pcidid == PCI_DEVICE_ID_CCD_M4) {
	    switch (tmp->subsystem_device) {
		case 0x08b4:
			if (ports == -1) ports = 0; /* assume TE mode if no ports param */
			printk(KERN_INFO
		        "qozap: CologneChip HFC-4S evaluation board configured at mem %#x IRQ %d HZ %d\n",
		          (u_int) qoztmp->pci_io,
		        qoztmp->irq, HZ);
		    break;
		case 0xb520:
			printk(KERN_INFO
		        "qozap: Junghanns.NET quadBRI card configured at mem %#x IRQ %d HZ %d CardID %d\n",
		          (u_int) qoztmp->pci_io,
		        qoztmp->irq, HZ, cid);
		    break;
	    } 
	    totalBRIs += 4;
	} else {
	    switch (tmp->subsystem_device) {
		case 0xb552:
		    printk(KERN_INFO
		       "qozap: Junghanns.NET octoBRI card configured at mem %#x IRQ %d HZ %d\n",
		       (u_int) qoztmp->pci_io,
		       qoztmp->irq, HZ);
	        break;
		default:
		    iounmap((void *) qoztmp->pci_io);
		    if (qoztmp->pcidev != NULL) {
    			pci_disable_device(qoztmp->pcidev);
		    }
		    pci_write_config_word(qoztmp->pcidev, PCI_COMMAND, 0);	// disable memio
		    free_irq(qoztmp->irq,qoztmp);
		    kfree(qoztmp);
		    qoztmp = NULL;
		    tmp = pci_find_device(PCI_VENDOR_ID_CCD,pcidid,multi_qoz);
		    continue;
		break;		
	    } 
	    totalBRIs += 8;
	}

	qoztmp->cardID = cid;
	qoztmp->type = tmp->subsystem_device;

	printk(KERN_INFO "qozap: S/T ports: %d [",qoztmp->stports);
	for (i=0;i<qoztmp->stports;i++) {
	    if ((modes & (1 << i)) != 0) {
	        qoztmp->st[i].nt_mode = 1;
	        printk(" NT");
	    } else {
	        qoztmp->st[i].nt_mode = 0;
	        printk(" TE");
	    }
	}
	printk(" ]\n");
	
	ztqoz->card = qoztmp;
	qoztmp->ztdev = ztqoz;

	qoz_registerCard(qoztmp);

	tmp = pci_find_device(PCI_VENDOR_ID_CCD,pcidid,multi_qoz);
    }
    return 0;
}


int qoz_sortCards(void) {
    int changed=0,tmpcardno;
    struct qoz_card *tmpcard,*tmpcard2;
    spin_lock(&registerlock);
    do {
	changed = 0;
	tmpcard = qoz_dev_list;
	while (tmpcard != NULL) {
	    if (tmpcard->prev) {
		if (tmpcard->prev->cardID > tmpcard->cardID) {
		    tmpcardno = tmpcard->prev->cardno;
		    tmpcard->prev->cardno = tmpcard->cardno; 
		    tmpcard->cardno = tmpcardno;
		
		    tmpcard2 = tmpcard->prev;
		    if (tmpcard2->prev) {
			tmpcard2->prev->next = tmpcard;
		    } else {
			qoz_dev_list = tmpcard;
		    }
		    if (tmpcard->next) {
			tmpcard->next->prev = tmpcard2;
		    } 
		    tmpcard2->next = tmpcard->next;
		    tmpcard->prev = tmpcard2->prev;
		    tmpcard->next = tmpcard2;
		    tmpcard2->prev = tmpcard;
		    changed = 1;
		    tmpcard = tmpcard2;
		}
	    }
	    tmpcard = tmpcard->next;
	}
    } while (changed == 1);
    spin_unlock(&registerlock);
    return 0;
}

int qoz_zapCards(void) {
    struct qoz_card *tmpcard;
    tmpcard = qoz_dev_list;
    while (tmpcard != NULL) {
	ztqoz_initialize(tmpcard->ztdev);
	qoz_resetCard(tmpcard);
	tmpcard = tmpcard->next;
    }
    return 0;
}


int init_module(void) {
    multi_qoz = NULL;
    qoz_findCards(PCI_DEVICE_ID_CCD_M4);
    qoz_findCards(PCI_DEVICE_ID_CCD_M);
    qoz_sortCards();
    qoz_zapCards();
    if (qoz_dev_count == 0) {
	printk(KERN_INFO "qozap: no multiBRI cards found.\n");
    } else {
	printk(KERN_INFO "qozap: %d multiBRI card(s) in this box, %d BRI ports total.\n",qoz_dev_count, totalBRIs);
    }
    return 0;
}

void cleanup_module(void) {
    struct qoz_card *tmpcard,*tmplist;
    int i=0;
    tmplist = qoz_dev_list;
    while (tmplist != NULL) {
	tmplist->dead = 1;
	qoz_shutdownCard(tmplist);
	tmplist = tmplist->next;
    }
    tmplist = qoz_dev_list;
    spin_lock(&registerlock);
    while (tmplist != NULL) {
	tmpcard = tmplist->next;
	kfree(tmplist);
	i++;
	tmplist = tmpcard;
    }
    spin_unlock(&registerlock);
    printk(KERN_INFO "qozap: shutdown %d multiBRI cards.\n", i);
}
#endif

MODULE_PARM(doubleclock,"i");
MODULE_PARM(ports,"i");
MODULE_PARM(debug,"i");
MODULE_DESCRIPTION("quad/octo BRI zaptel driver");
MODULE_AUTHOR("Klaus-Peter Junghanns <kpj@junghanns.net>");
#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif	
