#!/bin/bash

wget http://www.asterisk-support.de/mirror/zaptel/zaptel-1.2.6.tar.gz
wget http://www.asterisk-support.de/mirror/libpri/libpri-1.2.3.tar.gz
wget http://www.asterisk-support.de/mirror/asterisk-1.2.9.1/asterisk-1.2.9.1.tar.gz

gzip -d ./*.gz

tar -xf zaptel-1.2.6.tar
tar -xf libpri-1.2.3.tar
tar -xf asterisk-1.2.9.1.tar

ln -s zaptel-1.2.6 zaptel
ln -s asterisk-1.2.9.1 asterisk
ln -s libpri-1.2.3 libpri
ln -s libgsmat-0.0.1 libgsmat

cd zaptel
patch -p1 < ../patches/zaptel.patch
cd ..

cd libpri-1.2.3
patch -p1 < ../patches/libpri.patch
cd ..

cd asterisk-1.2.9.1
patch -p1 < ../patches/asterisk.patch
cd ..

echo "****************************************************"
echo "         Downloading and patching finished."
echo "****************************************************"
