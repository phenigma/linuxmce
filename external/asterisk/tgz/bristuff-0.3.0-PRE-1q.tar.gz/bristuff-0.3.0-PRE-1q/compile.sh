#!/bin/bash

cd zaptel
make clean all
make install
cd ..

echo "****************************************************"
echo "ZAPTEL installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd libpri
make clean all
make install
cd ..

echo "****************************************************"
echo "LIBPRI installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd libgsmat
make clean all
make install
cd ..

echo "****************************************************"
echo "LIBGSM installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd ztgsm
make clean all
make install
cd ..

echo "****************************************************"
echo "uno/duo/quad GSM PCI driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read


cd qozap
make clean all
make install
cd ..

echo "****************************************************"
echo "quadBRI driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd cwain
make clean all
make install
cd ..

echo "****************************************************"
echo "cwain driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd zaphfc
make clean all
make install
cd ..

echo "****************************************************"
echo "hfc-pci driver installed."
echo "Press <Enter> to continue, or <CTRL> + <C> to abort."
echo "****************************************************"
read

cd asterisk
make clean 
make all
make install

# to install sample asterisk configuration files uncomment the next line
#make samples
cd ..


echo "****************************************************"
echo " ASTERISK installed."
echo "             Installation finished."
echo "****************************************************"
