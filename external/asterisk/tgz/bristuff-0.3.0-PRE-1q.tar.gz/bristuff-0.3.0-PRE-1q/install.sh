#!/bin/bash

./download.sh
./compile.sh
