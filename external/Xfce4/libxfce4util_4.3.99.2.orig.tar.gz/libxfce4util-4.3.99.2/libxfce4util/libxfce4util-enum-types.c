
/* Generated data (by glib-mkenums) */

#include <libxfce4util/libxfce4util.h>
#include <libxfce4util/libxfce4util-alias.h>

/* enumerations from "xfce-license.h" */
GType
xfce_license_text_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_LICENSE_TEXT_BSD, "XFCE_LICENSE_TEXT_BSD", "bsd" },
      { XFCE_LICENSE_TEXT_GPL, "XFCE_LICENSE_TEXT_GPL", "gpl" },
      { XFCE_LICENSE_TEXT_LGPL, "XFCE_LICENSE_TEXT_LGPL", "lgpl" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceLicenseTextType", values);
  }
  return etype;
}

/* enumerations from "xfce-resource.h" */
GType
xfce_resource_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_RESOURCE_DATA, "XFCE_RESOURCE_DATA", "data" },
      { XFCE_RESOURCE_CONFIG, "XFCE_RESOURCE_CONFIG", "config" },
      { XFCE_RESOURCE_CACHE, "XFCE_RESOURCE_CACHE", "cache" },
      { XFCE_RESOURCE_ICONS, "XFCE_RESOURCE_ICONS", "icons" },
      { XFCE_RESOURCE_THEMES, "XFCE_RESOURCE_THEMES", "themes" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceResourceType", values);
  }
  return etype;
}

#define __LIBXFCE4UTIL_ENUM_TYPES_C__
#include <libxfce4util/libxfce4util-aliasdef.c>

/* Generated data ends here */

