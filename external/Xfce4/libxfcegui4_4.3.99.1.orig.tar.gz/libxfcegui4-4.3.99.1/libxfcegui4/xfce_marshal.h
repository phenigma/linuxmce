
#ifndef __p_xfce_marshal_MARSHAL_H__
#define __p_xfce_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:INT,INT (xfce_marshal.list:25) */
extern void p_xfce_marshal_VOID__INT_INT (GClosure     *closure,
                                          GValue       *return_value,
                                          guint         n_param_values,
                                          const GValue *param_values,
                                          gpointer      invocation_hint,
                                          gpointer      marshal_data);

/* VOID:OBJECT,LONG,UINT,STRING (xfce_marshal.list:26) */
extern void p_xfce_marshal_VOID__OBJECT_LONG_UINT_STRING (GClosure     *closure,
                                                          GValue       *return_value,
                                                          guint         n_param_values,
                                                          const GValue *param_values,
                                                          gpointer      invocation_hint,
                                                          gpointer      marshal_data);

/* VOID:OBJECT,LONG (xfce_marshal.list:27) */
extern void p_xfce_marshal_VOID__OBJECT_LONG (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

G_END_DECLS

#endif /* __p_xfce_marshal_MARSHAL_H__ */

