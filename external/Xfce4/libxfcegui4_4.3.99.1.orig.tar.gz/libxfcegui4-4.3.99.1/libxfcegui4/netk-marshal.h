
#ifndef __p_netk_marshal_MARSHAL_H__
#define __p_netk_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:FLAGS,FLAGS (netk-marshal.list:25) */
extern void p_netk_marshal_VOID__FLAGS_FLAGS (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

/* VOID:OBJECT,UINT,UINT,STRING (netk-marshal.list:26) */
extern void p_netk_marshal_VOID__OBJECT_UINT_UINT_STRING (GClosure     *closure,
                                                          GValue       *return_value,
                                                          guint         n_param_values,
                                                          const GValue *param_values,
                                                          gpointer      invocation_hint,
                                                          gpointer      marshal_data);

/* VOID:OBJECT,UINT (netk-marshal.list:27) */
extern void p_netk_marshal_VOID__OBJECT_UINT (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

G_END_DECLS

#endif /* __p_netk_marshal_MARSHAL_H__ */

