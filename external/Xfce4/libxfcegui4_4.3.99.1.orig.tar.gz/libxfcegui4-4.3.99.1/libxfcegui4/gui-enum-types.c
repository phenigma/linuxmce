
/* Generated data (by glib-mkenums) */

#include <libxfcegui4/libxfcegui4.h>

/* enumerations from "icons.h" */
GType
xfce_icon_theme_category_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_ICON_CATEGORY_UNKNOWN, "XFCE_ICON_CATEGORY_UNKNOWN", "unknown" },
      { XFCE_ICON_CATEGORY_EDITOR, "XFCE_ICON_CATEGORY_EDITOR", "editor" },
      { XFCE_ICON_CATEGORY_FILEMAN, "XFCE_ICON_CATEGORY_FILEMAN", "fileman" },
      { XFCE_ICON_CATEGORY_UTILITY, "XFCE_ICON_CATEGORY_UTILITY", "utility" },
      { XFCE_ICON_CATEGORY_GAME, "XFCE_ICON_CATEGORY_GAME", "game" },
      { XFCE_ICON_CATEGORY_HELP, "XFCE_ICON_CATEGORY_HELP", "help" },
      { XFCE_ICON_CATEGORY_MULTIMEDIA, "XFCE_ICON_CATEGORY_MULTIMEDIA", "multimedia" },
      { XFCE_ICON_CATEGORY_NETWORK, "XFCE_ICON_CATEGORY_NETWORK", "network" },
      { XFCE_ICON_CATEGORY_GRAPHICS, "XFCE_ICON_CATEGORY_GRAPHICS", "graphics" },
      { XFCE_ICON_CATEGORY_PRINTER, "XFCE_ICON_CATEGORY_PRINTER", "printer" },
      { XFCE_ICON_CATEGORY_PRODUCTIVITY, "XFCE_ICON_CATEGORY_PRODUCTIVITY", "productivity" },
      { XFCE_ICON_CATEGORY_OFFICE, "XFCE_ICON_CATEGORY_OFFICE", "office" },
      { XFCE_ICON_CATEGORY_SOUND, "XFCE_ICON_CATEGORY_SOUND", "sound" },
      { XFCE_ICON_CATEGORY_TERMINAL, "XFCE_ICON_CATEGORY_TERMINAL", "terminal" },
      { XFCE_ICON_CATEGORY_DEVELOPMENT, "XFCE_ICON_CATEGORY_DEVELOPMENT", "development" },
      { XFCE_ICON_CATEGORY_SETTINGS, "XFCE_ICON_CATEGORY_SETTINGS", "settings" },
      { XFCE_ICON_CATEGORY_SYSTEM, "XFCE_ICON_CATEGORY_SYSTEM", "system" },
      { XFCE_ICON_CATEGORY_WINE, "XFCE_ICON_CATEGORY_WINE", "wine" },
      { XFCE_ICON_CATEGORY_ACCESSORIES, "XFCE_ICON_CATEGORY_ACCESSORIES", "accessories" },
      { XFCE_N_BUILTIN_ICON_CATEGORIES, "XFCE_N_BUILTIN_ICON_CATEGORIES", "xfce-n-builtin-icon-categories" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceIconThemeCategory", values);
  }
  return etype;
}

/* enumerations from "xfce_clock.h" */
GType
xfce_clock_mode_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_CLOCK_ANALOG, "XFCE_CLOCK_ANALOG", "analog" },
      { XFCE_CLOCK_DIGITAL, "XFCE_CLOCK_DIGITAL", "digital" },
      { XFCE_CLOCK_LEDS, "XFCE_CLOCK_LEDS", "leds" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceClockMode", values);
  }
  return etype;
}
GType
xfce_clock_led_size_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { DIGIT_SMALL, "DIGIT_SMALL", "small" },
      { DIGIT_MEDIUM, "DIGIT_MEDIUM", "medium" },
      { DIGIT_LARGE, "DIGIT_LARGE", "large" },
      { DIGIT_HUGE, "DIGIT_HUGE", "huge" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceClockLedSize", values);
  }
  return etype;
}

/* enumerations from "xfce_decorbutton.h" */
GType
xfce_decorbutton_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_DECORBUTTON_CLOSE, "XFCE_DECORBUTTON_CLOSE", "close" },
      { XFCE_DECORBUTTON_HIDE, "XFCE_DECORBUTTON_HIDE", "hide" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceDecorbuttonType", values);
  }
  return etype;
}

/* enumerations from "xfce-filechooser.h" */
GType
xfce_file_chooser_action_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XFCE_FILE_CHOOSER_ACTION_OPEN, "XFCE_FILE_CHOOSER_ACTION_OPEN", "open" },
      { XFCE_FILE_CHOOSER_ACTION_SAVE, "XFCE_FILE_CHOOSER_ACTION_SAVE", "save" },
      { XFCE_FILE_CHOOSER_ACTION_SELECT_FOLDER, "XFCE_FILE_CHOOSER_ACTION_SELECT_FOLDER", "select-folder" },
      { XFCE_FILE_CHOOSER_ACTION_CREATE_FOLDER, "XFCE_FILE_CHOOSER_ACTION_CREATE_FOLDER", "create-folder" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceFileChooserAction", values);
  }
  return etype;
}

/* enumerations from "session-client.h" */
GType
session_interact_style_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { SESSION_INTERACT_NONE, "SESSION_INTERACT_NONE", "none" },
      { SESSION_INTERACT_ERRORS, "SESSION_INTERACT_ERRORS", "errors" },
      { SESSION_INTERACT_ANY, "SESSION_INTERACT_ANY", "any" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("SessionInteractStyle", values);
  }
  return etype;
}
GType
session_restart_style_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { SESSION_RESTART_IF_RUNNING, "SESSION_RESTART_IF_RUNNING", "if-running" },
      { SESSION_RESTART_ANYWAY, "SESSION_RESTART_ANYWAY", "anyway" },
      { SESSION_RESTART_IMMEDIATELY, "SESSION_RESTART_IMMEDIATELY", "immediately" },
      { SESSION_RESTART_NEVER, "SESSION_RESTART_NEVER", "never" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("SessionRestartStyle", values);
  }
  return etype;
}
GType
session_client_state_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { SESSION_CLIENT_IDLE, "SESSION_CLIENT_IDLE", "idle" },
      { SESSION_CLIENT_SAVING_PHASE_1, "SESSION_CLIENT_SAVING_PHASE_1", "saving-phase-1" },
      { SESSION_CLIENT_WAITING_FOR_PHASE_2, "SESSION_CLIENT_WAITING_FOR_PHASE_2", "waiting-for-phase-2" },
      { SESSION_CLIENT_SAVING_PHASE_2, "SESSION_CLIENT_SAVING_PHASE_2", "saving-phase-2" },
      { SESSION_CLIENT_WAITING_FOR_INTERACT, "SESSION_CLIENT_WAITING_FOR_INTERACT", "waiting-for-interact" },
      { SESSION_CLIENT_DONE_WITH_INTERACT, "SESSION_CLIENT_DONE_WITH_INTERACT", "done-with-interact" },
      { SESSION_CLIENT_FROZEN, "SESSION_CLIENT_FROZEN", "frozen" },
      { SESSION_CLIENT_DISCONNECTED, "SESSION_CLIENT_DISCONNECTED", "disconnected" },
      { SESSION_CLIENT_REGISTERING, "SESSION_CLIENT_REGISTERING", "registering" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("SessionClientState", values);
  }
  return etype;
}

/* enumerations from "gtktoxevent.h" */
GType
xfce_filter_status_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { XEV_FILTER_STOP, "XEV_FILTER_STOP", "stop" },
      { XEV_FILTER_CONTINUE, "XEV_FILTER_CONTINUE", "continue" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("XfceFilterStatus", values);
  }
  return etype;
}

/* Generated data ends here */

