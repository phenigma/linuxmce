
/* Generated data (by glib-mkenums) */

#include <libxfcegui4/libxfcegui4.h>

/* enumerations from "netk-window.h" */
GType
netk_window_state_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GFlagsValue values[] = {
      { NETK_WINDOW_STATE_MINIMIZED, "NETK_WINDOW_STATE_MINIMIZED", "minimized" },
      { NETK_WINDOW_STATE_MAXIMIZED_HORIZONTALLY, "NETK_WINDOW_STATE_MAXIMIZED_HORIZONTALLY", "maximized-horizontally" },
      { NETK_WINDOW_STATE_MAXIMIZED_VERTICALLY, "NETK_WINDOW_STATE_MAXIMIZED_VERTICALLY", "maximized-vertically" },
      { NETK_WINDOW_STATE_SHADED, "NETK_WINDOW_STATE_SHADED", "shaded" },
      { NETK_WINDOW_STATE_SKIP_PAGER, "NETK_WINDOW_STATE_SKIP_PAGER", "skip-pager" },
      { NETK_WINDOW_STATE_SKIP_TASKLIST, "NETK_WINDOW_STATE_SKIP_TASKLIST", "skip-tasklist" },
      { NETK_WINDOW_STATE_STICKY, "NETK_WINDOW_STATE_STICKY", "sticky" },
      { NETK_WINDOW_STATE_HIDDEN, "NETK_WINDOW_STATE_HIDDEN", "hidden" },
      { NETK_WINDOW_STATE_FULLSCREEN, "NETK_WINDOW_STATE_FULLSCREEN", "fullscreen" },
      { NETK_WINDOW_STATE_URGENT, "NETK_WINDOW_STATE_URGENT", "urgent" },
      { NETK_WINDOW_STATE_DEMANDS_ATTENTION, "NETK_WINDOW_STATE_DEMANDS_ATTENTION", "demands-attention" },
      { 0, NULL, NULL }
    };
    etype = g_flags_register_static ("NetkWindowState", values);
  }
  return etype;
}
GType
netk_window_actions_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GFlagsValue values[] = {
      { NETK_WINDOW_ACTION_MOVE, "NETK_WINDOW_ACTION_MOVE", "move" },
      { NETK_WINDOW_ACTION_RESIZE, "NETK_WINDOW_ACTION_RESIZE", "resize" },
      { NETK_WINDOW_ACTION_SHADE, "NETK_WINDOW_ACTION_SHADE", "shade" },
      { NETK_WINDOW_ACTION_STICK, "NETK_WINDOW_ACTION_STICK", "stick" },
      { NETK_WINDOW_ACTION_MAXIMIZE_HORIZONTALLY, "NETK_WINDOW_ACTION_MAXIMIZE_HORIZONTALLY", "maximize-horizontally" },
      { NETK_WINDOW_ACTION_MAXIMIZE_VERTICALLY, "NETK_WINDOW_ACTION_MAXIMIZE_VERTICALLY", "maximize-vertically" },
      { NETK_WINDOW_ACTION_CHANGE_WORKSPACE, "NETK_WINDOW_ACTION_CHANGE_WORKSPACE", "change-workspace" },
      { NETK_WINDOW_ACTION_CLOSE, "NETK_WINDOW_ACTION_CLOSE", "close" },
      { NETK_WINDOW_ACTION_UNMAXIMIZE_HORIZONTALLY, "NETK_WINDOW_ACTION_UNMAXIMIZE_HORIZONTALLY", "unmaximize-horizontally" },
      { NETK_WINDOW_ACTION_UNMAXIMIZE_VERTICALLY, "NETK_WINDOW_ACTION_UNMAXIMIZE_VERTICALLY", "unmaximize-vertically" },
      { NETK_WINDOW_ACTION_UNSHADE, "NETK_WINDOW_ACTION_UNSHADE", "unshade" },
      { NETK_WINDOW_ACTION_UNSTICK, "NETK_WINDOW_ACTION_UNSTICK", "unstick" },
      { NETK_WINDOW_ACTION_MINIMIZE, "NETK_WINDOW_ACTION_MINIMIZE", "minimize" },
      { NETK_WINDOW_ACTION_UNMINIMIZE, "NETK_WINDOW_ACTION_UNMINIMIZE", "unminimize" },
      { NETK_WINDOW_ACTION_MAXIMIZE, "NETK_WINDOW_ACTION_MAXIMIZE", "maximize" },
      { NETK_WINDOW_ACTION_UNMAXIMIZE, "NETK_WINDOW_ACTION_UNMAXIMIZE", "unmaximize" },
      { 0, NULL, NULL }
    };
    etype = g_flags_register_static ("NetkWindowActions", values);
  }
  return etype;
}
GType
netk_window_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { NETK_WINDOW_NORMAL, "NETK_WINDOW_NORMAL", "normal" },
      { NETK_WINDOW_DESKTOP, "NETK_WINDOW_DESKTOP", "desktop" },
      { NETK_WINDOW_DOCK, "NETK_WINDOW_DOCK", "dock" },
      { NETK_WINDOW_DIALOG, "NETK_WINDOW_DIALOG", "dialog" },
      { NETK_WINDOW_MODAL_DIALOG, "NETK_WINDOW_MODAL_DIALOG", "modal-dialog" },
      { NETK_WINDOW_TOOLBAR, "NETK_WINDOW_TOOLBAR", "toolbar" },
      { NETK_WINDOW_MENU, "NETK_WINDOW_MENU", "menu" },
      { NETK_WINDOW_UTILITY, "NETK_WINDOW_UTILITY", "utility" },
      { NETK_WINDOW_SPLASHSCREEN, "NETK_WINDOW_SPLASHSCREEN", "splashscreen" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("NetkWindowType", values);
  }
  return etype;
}

/* enumerations from "netk-pager.h" */
GType
netk_pager_display_mode_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { NETK_PAGER_DISPLAY_NAME, "NETK_PAGER_DISPLAY_NAME", "name" },
      { NETK_PAGER_DISPLAY_CONTENT, "NETK_PAGER_DISPLAY_CONTENT", "content" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("NetkPagerDisplayMode", values);
  }
  return etype;
}

/* enumerations from "netk-tasklist.h" */
GType
netk_tasklist_grouping_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { NETK_TASKLIST_NEVER_GROUP, "NETK_TASKLIST_NEVER_GROUP", "never-group" },
      { NETK_TASKLIST_AUTO_GROUP, "NETK_TASKLIST_AUTO_GROUP", "auto-group" },
      { NETK_TASKLIST_ALWAYS_GROUP, "NETK_TASKLIST_ALWAYS_GROUP", "always-group" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("NetkTasklistGroupingType", values);
  }
  return etype;
}

/* Generated data ends here */

