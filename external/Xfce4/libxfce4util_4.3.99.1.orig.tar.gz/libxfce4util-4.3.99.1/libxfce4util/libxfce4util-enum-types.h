
/* Generated data (by glib-mkenums) */

#ifndef __LIBXFCE4UTIL_ENUM_TYPES_H__
#define __LIBXFCE4UTIL_ENUM_TYPES_H__
#include <glib-object.h>
/* enumerations from "xfce-license.h" */
GType xfce_license_text_type_get_type (void) G_GNUC_CONST;
#define XFCE_TYPE_LICENSE_TEXT_TYPE (xfce_license_text_type_get_type())
/* enumerations from "xfce-resource.h" */
GType xfce_resource_type_get_type (void) G_GNUC_CONST;
#define XFCE_TYPE_RESOURCE_TYPE (xfce_resource_type_get_type())
#endif /* __LIBXFCE4UTIL_ENUM_TYPES_H__ */

/* Generated data ends here */

