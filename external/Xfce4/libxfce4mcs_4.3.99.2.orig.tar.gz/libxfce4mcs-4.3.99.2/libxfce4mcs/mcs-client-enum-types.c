
/* Generated data (by glib-mkenums) */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <glib-object.h>
#include <libxfce4mcs/mcs-common.h>
#include <libxfce4mcs/mcs-client.h>

/* enumerations from "mcs-client.h" */
GType
mcs_action_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { MCS_ACTION_NEW, "MCS_ACTION_NEW", "new" },
      { MCS_ACTION_CHANGED, "MCS_ACTION_CHANGED", "changed" },
      { MCS_ACTION_DELETED, "MCS_ACTION_DELETED", "deleted" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("McsAction", values);
  }
  return etype;
}

/* enumerations from "mcs-common.h" */
GType
mcs_type_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { MCS_TYPE_INT, "MCS_TYPE_INT", "int" },
      { MCS_TYPE_STRING, "MCS_TYPE_STRING", "string" },
      { MCS_TYPE_COLOR, "MCS_TYPE_COLOR", "color" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("McsType", values);
  }
  return etype;
}
GType
mcs_result_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { MCS_SUCCESS, "MCS_SUCCESS", "success" },
      { MCS_NO_MEM, "MCS_NO_MEM", "no-mem" },
      { MCS_ACCESS, "MCS_ACCESS", "access" },
      { MCS_FAILED, "MCS_FAILED", "failed" },
      { MCS_NO_ENTRY, "MCS_NO_ENTRY", "no-entry" },
      { MCS_DUPLICATE_ENTRY, "MCS_DUPLICATE_ENTRY", "duplicate-entry" },
      { MCS_NO_CHANNEL, "MCS_NO_CHANNEL", "no-channel" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("McsResult", values);
  }
  return etype;
}
GType
mcs_manager_check_get_type (void)
{
  static GType etype = 0;
  if (etype == 0) {
    static const GEnumValue values[] = {
      { MCS_MANAGER_NONE, "MCS_MANAGER_NONE", "none" },
      { MCS_MANAGER_STD, "MCS_MANAGER_STD", "std" },
      { MCS_MANAGER_MULTI_CHANNEL, "MCS_MANAGER_MULTI_CHANNEL", "multi-channel" },
      { MCS_MANAGER_BOTH, "MCS_MANAGER_BOTH", "both" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static ("McsManagerCheck", values);
  }
  return etype;
}

/* Generated data ends here */

