
/* Generated data (by glib-mkenums) */

#ifndef __MCS_ENUM_TYPES_H__
#define __MCS_ENUM_TYPES_H__
/* enumerations from "mcs-client.h" */
GType mcs_action_get_type (void);
#define MCS_TYPE_ACTION (mcs_action_get_type())
/* enumerations from "mcs-common.h" */
GType mcs_type_get_type (void);
#define MCS_TYPE_TYPE (mcs_type_get_type())
GType mcs_result_get_type (void);
#define MCS_TYPE_RESULT (mcs_result_get_type())
GType mcs_manager_check_get_type (void);
#define MCS_TYPE_MANAGER_CHECK (mcs_manager_check_get_type())
#endif /* __MCS_ENUM_TYPES_H__ */

/* Generated data ends here */

