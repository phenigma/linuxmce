#ifndef __XFCE_STARTUP_NOTIFICATION_H
#define __XFCE_STARTUP_NOTIFICATION_H

/* not thread safe */

/* returns: id */
char* xfce_startup_notification_start(GdkScreen* screen, char const* path);

void xfce_startup_notification_cancel(const char* id);

#define XFCE_STARTUP_NOTIFICATION_ENVIRONMENT_DESKTOP_STARTUP_ID "DESKTOP_STARTUP_ID"

char** xfce_startup_notification_modify_environment(const char** envp, const char* id);
char** xfce_startup_notification_cleanup_environment(const char** envp);

#endif
