<?php

/**
 * @file
 * main
 */

include_once("includes/bootstrap.inc");
ari_page_header();
include_once("includes/common.inc");

handler();

ari_page_footer();


?>



