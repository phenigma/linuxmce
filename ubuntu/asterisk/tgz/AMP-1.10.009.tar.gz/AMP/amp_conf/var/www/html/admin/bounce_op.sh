#!/bin/bash
killall op_server.pl

