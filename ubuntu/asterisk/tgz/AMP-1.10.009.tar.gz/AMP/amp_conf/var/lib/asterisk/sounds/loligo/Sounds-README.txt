These sounds were recorded in March of 2003 by Allison Smith, who does PBX
voicemail voices for hire.  She does a great job!  I gave her a list of
words and phrases, and within an hour or so of transmission she had sent me
back a continuous file of what I needed.  I cut the file up into pieces, and
some of them are in this directory for your use.  Note: she did not, in
fact, make the monkey noises.

Allison Smith: http://www.theivrvoice.com/

Me: jtodd@loligo.com


-- Update 2003-07-11
I have been able to contract with Allison for more sounds thanks to  a
generous grant from VoicePulse (http://www.voicepulse.com) These sounds have
have been donated to the Asterisk community.  Many of these sounds will
probably find their way into the Asterisk standard distribution (notably the
number enunciations, which are useful for speaking dates.)   However, the
rest are for general consumption.

I have added a file called "sounds-extra.txt" which contains all of the
names of the sound files and their contents.

These sounds are BSD-licensed, meaning that they can be used for any
purpose, including incorporation into commercial packages.  Since voice
prompts can't really be modified and/or improved, putting them in the GPL
just seems a bit silly, and I am in favor of BSD licensing anyway.


-- Update 2004-01-17 
MORE sounds!  Whee!  Your generous donations are appreciated.

